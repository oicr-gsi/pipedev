--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE PROCEDURAL LANGUAGE plpgsql;


ALTER PROCEDURAL LANGUAGE plpgsql OWNER TO postgres;

SET search_path = public, pg_catalog;

--
-- Name: FileReportDelete(); Type: FUNCTION; Schema: public; Owner: seqware
--

CREATE FUNCTION "FileReportDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN 
  DELETE FROM file_report fr
  WHERE fr.file_id = OLD.file_id;

  RETURN NEW;
END
  $$;


ALTER FUNCTION public."FileReportDelete"() OWNER TO seqware;

--
-- Name: FileReportInsert(); Type: FUNCTION; Schema: public; Owner: seqware
--

CREATE FUNCTION "FileReportInsert"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE 
  _study_id INTEGER;
  _root_sample_id INTEGER;
  _child_sample_id INTEGER;
  _parent_sample_id INTEGER;
  _tissue_source VARCHAR(255);
  _library_type VARCHAR(255);
  _template_type VARCHAR(255);
  _ius_swid INTEGER;
  _lane_id INTEGER;
  _file_path TEXT;
  _processing_id INTEGER;
  _experiment_id INTEGER;
  _file_id INTEGER;

  -- tmp
  _parent_processing_id INTEGER;
  _child_processing_id INTEGER;
  _bottom_processing_id INTEGER;
  _bottom_sample_id INTEGER;
  _ius_id INTEGER;

BEGIN
  --PERFORM lock_ns_tree(NEW.tree);
  RAISE NOTICE 'START TRIGGER';
  SELECT file_path INTO _file_path FROM file 
	WHERE file.file_id = NEW.file_id;
  _processing_id := NEW.processing_id;
  _file_id := NEW.file_id;
	
  RAISE NOTICE 'FILE PATH %', _file_path;

  FOR _ius_id IN 
		WITH RECURSIVE rec (parent_id, child_id) AS (
		select _processing_id, null
		union 
		select pr.parent_id, r.child_id from processing_relationship pr, rec r
		where r.parent_id = pr.child_id )

		select pi.ius_id from rec r
		join processing_ius pi on (r.parent_id = pi.processing_id)
		--union 
		--select ius_id from ius_workflow_runs where workflow_run_id = _workflow_run_id
		  --SELECT pi.ius_id FROM processing_ius pi
				 --WHERE pi.processing_id = _processing_id
  LOOP
    SELECT i.sw_accession, i.lane_id, i.sample_id INTO _ius_swid, _lane_id, _child_sample_id 
    FROM ius i
    WHERE i.ius_id = _ius_id;

    -- Determine Root Sample
    FOR _root_sample_id IN
		WITH RECURSIVE rec (parent_id, child_id) AS (
		SELECT _child_sample_id, null
		UNION
		SELECT sr.parent_id, r.child_id FROM sample_relationship sr, rec r
		WHERE r.parent_id = sr.child_id )
		SELECT parent_id FROM rec
    LOOP
      SELECT experiment_id INTO _experiment_id FROM sample
      WHERE sample_id = _root_sample_id;
      IF _experiment_id IS NOT NULL THEN
        SELECT s.study_id INTO _study_id FROM study s
	JOIN experiment e ON (s.study_id = e.study_id)
	WHERE e.experiment_id = _experiment_id;

	-- FIND parent sample
	WITH RECURSIVE rec(parent_id) AS (
	SELECT parent_id FROM sample_hierarchy
	WHERE sample_id = _root_sample_id
	UNION
	SELECT sh.parent_id FROM sample_hierarchy sh, rec r
	WHERE sh.sample_id = r.parent_id )
	SELECT r.parent_id INTO _parent_sample_id FROM rec r, sample_hierarchy sh
	WHERE r.parent_id = sh.sample_id
	AND sh.parent_id IS NULL;

	IF _parent_sample_id IS NULL THEN
	  _parent_sample_id := _root_sample_id;
	END IF;

	INSERT INTO file_report(study_id, experiment_id, sample_id, child_sample_id, ius_id, lane_id, processing_id, file_id) 
	VALUES (_study_id, _experiment_id, _parent_sample_id, _child_sample_id, _ius_id, _lane_id, _processing_id, _file_id);
      END IF;
    END LOOP;
		
  END LOOP;
  
  RETURN NEW;
END
  
  $$;


ALTER FUNCTION public."FileReportInsert"() OWNER TO seqware;

--
-- Name: SampleReportDelete(); Type: FUNCTION; Schema: public; Owner: seqware
--

CREATE FUNCTION "SampleReportDelete"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE 
  _old_status VARCHAR(255);
  _new_status VARCHAR(255);
  _current_status VARCHAR(255);

  _processing_id INTEGER;
  _child_processing_id INTEGER;
  _child_sample_id INTEGER;
  _root_sample_id INTEGER;
  _ius_id INTEGER;
  _study_id INTEGER;
  _workflow_id INTEGER;
  _workflow_run_id INTEGER;

BEGIN
  _workflow_id := OLD.workflow_id;
  _workflow_run_id := OLD.workflow_run_id;
  _new_status := OLD.status;
  RAISE NOTICE 'Workflow %', _workflow_id;
   
  -- find appropriate IUS_ID
  FOR _ius_id IN 
		 -- More reliable solution
		WITH RECURSIVE rec (parent_id, child_id) AS (
		select processing_id, null from processing where workflow_run_id = _workflow_run_id
		union 
		select pr.parent_id, r.child_id from processing_relationship pr, rec r
		where r.parent_id = pr.child_id )

		select pi.ius_id from rec r
		join processing_ius pi on (r.parent_id = pi.processing_id)
		union 
		select ius_id from ius_workflow_runs where workflow_run_id = _workflow_run_id

  LOOP

	  RAISE NOTICE 'IUS %', _ius_id;
	  
	  IF _ius_id IS NOT NULL THEN
	 
		  SELECT sample_id INTO _child_sample_id FROM ius
		  WHERE ius_id = _ius_id;

		  --RAISE NOTICE 'Child Sample %', _child_sample_id;
		  
		  -- look for the root sample
		  LOOP
			SELECT sr.parent_id INTO _root_sample_id FROM sample_relationship sr
				WHERE sr.child_id = _child_sample_id;
				
			IF _root_sample_id IS NULL THEN -- this is the top processing element
				_root_sample_id := _child_sample_id;
				EXIT;
			END IF;
		  
			_child_sample_id := _root_sample_id;
			
		  END LOOP;

		  --RAISE NOTICE 'Root Sample %', _root_sample_id;

		  -- get relevant study_id
		  SELECT s.study_id INTO _study_id FROM study s, experiment e, sample sa
		  WHERE s.study_id = e.study_id
		  AND e.experiment_id = sa.experiment_id
		  AND sa.sample_id = _root_sample_id;

		  -- Update 
		  SELECT current_status_new(_ius_id, _workflow_id) INTO _current_status;
		  SELECT status INTO _old_status FROM sample_report
		  WHERE study_id = _study_id
		  AND child_sample_id = _child_sample_id
		  AND workflow_id = _workflow_id;

		  RAISE NOTICE 'Current Status %', _current_status;
		  RAISE NOTICE 'New Status %', _new_status;
		  RAISE NOTICE 'Old Status %', _old_status;

		  IF _current_status IS NULL THEN
		    DELETE FROM sample_report
		    WHERE study_id = _study_id 
		    AND child_sample_id = _child_sample_id
		    AND workflow_id = _workflow_id;
		  ELSE
		      UPDATE sample_report SET status = _current_status
		      WHERE study_id = _study_id
		      AND child_sample_id = _child_sample_id
		      AND workflow_id = _workflow_id;
		  END IF;  
		 
	END IF;
  END LOOP;

  RETURN NEW;
END;$$;


ALTER FUNCTION public."SampleReportDelete"() OWNER TO seqware;

--
-- Name: SampleReportUpdate(); Type: FUNCTION; Schema: public; Owner: seqware
--

CREATE FUNCTION "SampleReportUpdate"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE 
  _old_status VARCHAR(255);
  _new_status VARCHAR(255);
  _current_status VARCHAR(255);

  _processing_id INTEGER;
  _child_processing_id INTEGER;
  _child_sample_id INTEGER;
  _root_sample_id INTEGER;
  _ius_id INTEGER;
  _study_id INTEGER;
  _workflow_id INTEGER;
  _workflow_run_id INTEGER;

BEGIN
  _workflow_id := NEW.workflow_id;
  _workflow_run_id := NEW.workflow_run_id;
  _new_status := NEW.status;
  RAISE NOTICE 'Workflow %', _workflow_id;
 /* FOR _processing_id IN SELECT processing_id FROM processing
			WHERE workflow_run_id = NEW.workflow_run_id
  LOOP

	  RAISE NOTICE 'Processing %', _processing_id;
	  
	  IF _processing_id IS NOT NULL THEN
	  
		  -- check if this processing_id belongs to right to the sample
		  SELECT ps.sample_id INTO _child_sample_id FROM processing_samples ps
		  WHERE ps.processing_id = _processing_id;

		  IF _child_sample_id IS NULL THEN
		  -- this is nested processing, look for the parent processing
		    _child_processing_id = _processing_id;
		    LOOP

		      SELECT pi.ius_id INTO _ius_id FROM processing_ius pi
				 WHERE pi.processing_id = _child_processing_id;
		      RAISE NOTICE 'IUS %', _ius_id;
		      PERFORM update_sample_report_processing( _child_processing_id, _workflow_id );

		      SELECT pr.parent_id INTO _processing_id FROM processing_relationship pr
		      WHERE pr.child_id = _child_processing_id;
			
		      IF _processing_id IS NULL THEN -- this is the top processing element
				_processing_id := _child_processing_id;
				EXIT;
		      END IF;
		      
		      _child_processing_id := _processing_id;

		    END LOOP;
		    SELECT ps.sample_id INTO _child_sample_id FROM processing_samples ps
		    WHERE ps.processing_id = _processing_id;
		  END IF;      

		  RAISE NOTICE 'Root Processing %', _processing_id;
		*/  
		  -- find appropriate IUS_ID
		  FOR _ius_id IN --SELECT ius_id from ius_workflow_runs 
				 --where workflow_run_id = _workflow_run_id
				 -- More reliable solution
				WITH RECURSIVE rec (parent_id, child_id) AS (
				select processing_id, null from processing where workflow_run_id = _workflow_run_id
				union 
				select pr.parent_id, r.child_id from processing_relationship pr, rec r
				where r.parent_id = pr.child_id )

				select pi.ius_id from rec r
				join processing_ius pi on (r.parent_id = pi.processing_id)
				union 
				select ius_id from ius_workflow_runs where workflow_run_id = _workflow_run_id
		  --SELECT pi.ius_id FROM processing_ius pi
				 --WHERE pi.processing_id = _processing_id
		  LOOP

			  RAISE NOTICE 'IUS %', _ius_id;
			  
			  IF _ius_id IS NOT NULL THEN
			 
				  SELECT sample_id INTO _child_sample_id FROM ius
				  WHERE ius_id = _ius_id;

				  --RAISE NOTICE 'Child Sample %', _child_sample_id;
				  
				  -- look for the root sample
				  LOOP
					SELECT sr.parent_id INTO _root_sample_id FROM sample_relationship sr
						WHERE sr.child_id = _child_sample_id;
						
					IF _root_sample_id IS NULL THEN -- this is the top processing element
						_root_sample_id := _child_sample_id;
						EXIT;
					END IF;
				  
					_child_sample_id := _root_sample_id;
					
				  END LOOP;

				  --RAISE NOTICE 'Root Sample %', _root_sample_id;

				  -- get relevant study_id
				  SELECT s.study_id INTO _study_id FROM study s, experiment e, sample sa
				  WHERE s.study_id = e.study_id
				  AND e.experiment_id = sa.experiment_id
				  AND sa.sample_id = _root_sample_id;

				  -- Update 
				  SELECT current_status_new(_ius_id, _workflow_id) INTO _current_status;
				  SELECT status INTO _old_status FROM sample_report
				  WHERE study_id = _study_id
				  AND child_sample_id = _child_sample_id
				  AND workflow_id = _workflow_id;

				  RAISE NOTICE 'Current Status %', _current_status;
				  RAISE NOTICE 'New Status %', _new_status;
				  RAISE NOTICE 'Old Status %', _old_status;

				  IF _old_status IS NULL THEN
				    INSERT INTO sample_report(study_id, child_sample_id, workflow_id, status)
				    VALUES (_study_id, _child_sample_id, _workflow_id, _new_status);
				  ELSE
				      UPDATE sample_report SET status = _current_status
				      WHERE study_id = _study_id
				      AND child_sample_id = _child_sample_id
				      AND workflow_id = _workflow_id;
				  END IF;  
				 
			END IF;
		  END LOOP;
/*	END IF;
  END LOOP; */
   RETURN NEW;
END;$$;


ALTER FUNCTION public."SampleReportUpdate"() OWNER TO seqware;

--
-- Name: current_status_new(integer, integer); Type: FUNCTION; Schema: public; Owner: seqware
--

CREATE FUNCTION current_status_new(_ius_id integer, _workflow_id integer) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$DECLARE
  _study_id INTEGER;
  _root_sample INTEGER;
  _sample_id INTEGER;
  _ius_id INTEGER;
  _lane_id INTEGER;
  _file_id INTEGER;
  _workflow_id INTEGER;

-- temp data
  _parent_sample_id INTEGER;
  _child_sample_id INTEGER;
  _processing_id INTEGER;
  _ius_data ius%ROWTYPE;
  _sample_record RECORD;
  _old_status VARCHAR(255);
  _new_status VARCHAR(255);
  _update_needed BOOLEAN;
  _workflow_run_id INTEGER;

BEGIN
--_study_id = $1;
--_sample_id = $2;
_ius_id = $1;
_workflow_id = $2;
--_old_status = 'notstarted';
FOR _processing_id IN 
	WITH RECURSIVE proces_to_leaf(child_id) AS (
		SELECT pi.processing_id FROM processing_ius pi
		WHERE pi.ius_id = _ius_id
		UNION
		SELECT pr.child_id FROM processing_relationship pr, proces_to_leaf pl
		WHERE pr.parent_id = pl.child_id )
	SELECT * FROM proces_to_leaf
LOOP
	SELECT wr.status, wr.workflow_run_id INTO _new_status, _workflow_run_id FROM processing p
	JOIN workflow_run wr ON (p.workflow_run_id = wr.workflow_run_id)
	WHERE p.processing_id = _processing_id
	AND wr.workflow_id = _workflow_id;

	IF _new_status IS NULL THEN
		-- check ancestor run for status
		SELECT wr.status, wr.workflow_run_id INTO _new_status, _workflow_run_id FROM processing p
		JOIN workflow_run wr ON (p.ancestor_workflow_run_id = wr.workflow_run_id)
		WHERE p.processing_id = _processing_id
		AND wr.workflow_id = _workflow_id;
	END IF;

	IF _new_status IS NOT NULL THEN
		-- now we have status for current workflow
		IF _old_status IS NULL THEN
		  _old_status := _new_status;
		ELSIF _new_status = 'completed' THEN
		  RETURN _new_status;
		ELSIF (_old_status = 'failed' 
			AND (_new_status = 'pending' or _new_status = 'running')) THEN
		  _old_status := _new_status;
		END IF;			
		--RAISE NOTICE 'PROCESSING %, STATUS %, WORKFLOW_RUN %', _processing_id, _old_status, _workflow_run_id;
	END IF;
END LOOP;
RETURN _old_status;
END;$_$;


ALTER FUNCTION public.current_status_new(_ius_id integer, _workflow_id integer) OWNER TO seqware;

--
-- Name: fill_file_report(); Type: FUNCTION; Schema: public; Owner: seqware
--

CREATE FUNCTION fill_file_report() RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
  _study_id INTEGER;
  _root_sample INTEGER;
  _sample_id INTEGER;
  _ius_id INTEGER;
  _lane_id INTEGER;
  _file_id INTEGER;
  _experiment_id INTEGER;

-- temp data
  _parent_sample_id INTEGER;
  _child_sample_id INTEGER;
  _processing_id INTEGER;
  _ius_data ius%ROWTYPE;
  _sample_record RECORD;

 -- _child_samples_id INTEGER ARRAY[4];

BEGIN
  FOR _study_id IN 
	SELECT study_id FROM study
  LOOP
	--RAISE NOTICE 'STUDY %', _study_id;
	FOR _sample_record IN -- SAMPLE_ID is Root Sample here
		WITH RECURSIVE root_to_leaf(root_sample, child_id) AS (
		SELECT sample_id, sample_id FROM sample s
		JOIN experiment e ON (s.experiment_id = e.experiment_id)
		JOIN study st ON (st.study_id = e.study_id)
		WHERE st.study_id = _study_id
		UNION
		SELECT rl.root_sample, sr.child_id FROM sample_relationship sr 
		JOIN root_to_leaf rl ON (sr.parent_id = rl.child_id) )
		select * from root_to_leaf
	LOOP
		_parent_sample_id := _sample_record.root_sample;
		-- FIND parent sample
		WITH RECURSIVE rec(parent_id) AS (
		SELECT parent_id FROM sample_hierarchy
		WHERE sample_id = _parent_sample_id
		UNION
		SELECT sh.parent_id FROM sample_hierarchy sh, rec r
		WHERE sh.sample_id = r.parent_id )
		SELECT r.parent_id INTO _parent_sample_id FROM rec r, sample_hierarchy sh
		WHERE r.parent_id = sh.sample_id
		AND sh.parent_id IS NULL;

		IF _parent_sample_id IS NULL THEN
		  _parent_sample_id := _sample_record.root_sample;
		END IF;
		
		_sample_id := _sample_record.child_id;
		SELECT experiment_id INTO _experiment_id FROM sample 
		WHERE sample_id = _parent_sample_id;
		--RAISE NOTICE 'SAMPLE ROOT %', _parent_sample_id;
		--RAISE NOTICE 'SAMPLE %', _sample_id;
		-- Let's get all IUSs here
		FOR _ius_data IN 
			SELECT * FROM ius i
			WHERE i.sample_id = _sample_id
		LOOP
			_ius_id := _ius_data.ius_id;
			_lane_id := _ius_data.lane_id;
			--RAISE NOTICE 'IUS %, LANE %', _ius_id, _lane_id;
			
			FOR _processing_id IN 
				WITH RECURSIVE proces_to_leaf(child_id) AS (
					SELECT pi.processing_id FROM processing_ius pi
					WHERE pi.ius_id = _ius_id
					UNION
					SELECT pr.child_id FROM processing_relationship pr, proces_to_leaf pl
					WHERE pr.parent_id = pl.child_id )
				SELECT * FROM proces_to_leaf
			LOOP
--				RAISE NOTICE 'PROCESSING %', _processing_id;
				IF EXISTS (SELECT file_id FROM processing_files
				WHERE processing_id = _processing_id) THEN
					FOR _file_id IN SELECT file_id FROM processing_files
						WHERE processing_id = _processing_id	
					LOOP
						--RAISE NOTICE 'FILE %', _file_id;
						INSERT INTO file_report (study_id, experiment_id, sample_id, child_sample_id, ius_id, lane_id, processing_id, file_id)
						VALUES (_study_id, _experiment_id, _parent_sample_id, _sample_id, _ius_id, _lane_id, _processing_id, _file_id);
					END LOOP;
				END IF;
			END LOOP;
		END LOOP;
	END LOOP;
  END LOOP;

  RETURN TRUE;
END;
$$;


ALTER FUNCTION public.fill_file_report() OWNER TO seqware;

--
-- Name: fill_sample_report(); Type: FUNCTION; Schema: public; Owner: seqware
--

CREATE FUNCTION fill_sample_report() RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
  _study_id INTEGER;
  _root_sample INTEGER;
  _sample_id INTEGER;
  _ius_id INTEGER;
  _lane_id INTEGER;
  _file_id INTEGER;
  _workflow_id INTEGER;
  _sequencer_run_id INTEGER;

-- temp data
  _parent_sample_id INTEGER;
  _child_sample_id INTEGER;
  _processing_id INTEGER;
  _ius_data ius%ROWTYPE;
  _sample_record RECORD;
  _old_status VARCHAR(255);
  _new_status VARCHAR(255);
  _update_needed BOOLEAN;

BEGIN
  FOR _study_id IN 
	SELECT study_id FROM study
  LOOP
	--RAISE NOTICE 'STUDY %', _study_id;
	FOR _sample_record IN -- SAMPLE_ID is Root Sample here
		WITH RECURSIVE root_to_leaf(root_sample, child_id) AS (
		SELECT sample_id, sample_id FROM sample s
		JOIN experiment e ON (s.experiment_id = e.experiment_id)
		JOIN study st ON (st.study_id = e.study_id)
		WHERE st.study_id = _study_id
		UNION
		SELECT rl.root_sample, sr.child_id FROM sample_relationship sr 
		JOIN root_to_leaf rl ON (sr.parent_id = rl.child_id) )
		select * from root_to_leaf
	LOOP
		_parent_sample_id := _sample_record.root_sample;
		_sample_id := _sample_record.child_id;
		--RAISE NOTICE 'SAMPLE ROOT %', _parent_sample_id;
		--RAISE NOTICE 'SAMPLE %', _sample_id;
		-- Let's get all IUSs here
		FOR _ius_data IN 
			SELECT * FROM ius i
			WHERE i.sample_id = _sample_id
		LOOP
			_ius_id := _ius_data.ius_id;
			_lane_id := _ius_data.lane_id;
			SELECT sequencer_run_id INTO _sequencer_run_id FROM lane
			WHERE lane_id = _lane_id;

			--RAISE NOTICE 'IUS %, LANE %', _ius_id, _lane_id;
			FOR _processing_id IN 
				WITH RECURSIVE proces_to_leaf(child_id) AS (
					SELECT pi.processing_id FROM processing_ius pi
					WHERE pi.ius_id = _ius_id
					UNION
					SELECT pr.child_id FROM processing_relationship pr, proces_to_leaf pl
					WHERE pr.parent_id = pl.child_id )
				SELECT * FROM proces_to_leaf
			LOOP
				SELECT wr.workflow_id, wr.status INTO _workflow_id, _new_status FROM processing p
				JOIN workflow_run wr ON (p.workflow_run_id = wr.workflow_run_id)
				WHERE p.processing_id = _processing_id;

				IF _new_status IS NULL THEN
					-- check ancestor run for status
					SELECT wr.status, wr.workflow_id INTO _new_status, _workflow_id FROM processing p
					JOIN workflow_run wr ON (p.ancestor_workflow_run_id = wr.workflow_run_id)
					WHERE p.processing_id = _processing_id;
				END IF;

				IF _workflow_id IS NOT NULL THEN
					IF EXISTS (SELECT status FROM sample_report 
						WHERE study_id = _study_id
						AND child_sample_id = _sample_id
						AND workflow_id = _workflow_id
						AND lane_id = _lane_id
						AND ius_id = _ius_id
						AND sequencer_run_id = _sequencer_run_id)
					THEN
						SELECT status INTO _old_status FROM sample_report 
						WHERE study_id = _study_id
						AND child_sample_id = _sample_id
						AND workflow_id = _workflow_id
						AND lane_id = _lane_id
						AND ius_id = _ius_id
						AND sequencer_run_id = _sequencer_run_id;
							
						_update_needed := false;
						IF ( _old_status != 'completed'
							AND _old_status != 'pending'
							AND _old_status != 'running'
							AND _old_status != 'failed') THEN
							_update_needed := true;
						ELSIF (_old_status = 'failed' 
							AND (_new_status = 'completed' or _new_status = 'pending' or _new_status = 'running')) THEN
							_update_needed := true;
						ELSIF ((_old_status = 'running' or _old_status = 'pending') and (_new_status = 'completed')) THEN
							_update_needed := true;
						END IF;
						
						IF _update_needed THEN
							UPDATE sample_report SET status = _new_status
							WHERE study_id = _study_id
							AND child_sample_id = _sample_id
							AND workflow_id = _workflow_id
							AND lane_id = _lane_id
							AND ius_id = _ius_id
							AND sequencer_run_id = _sequencer_run_id;
						END IF;
					ELSE 
						INSERT INTO sample_report(study_id, child_sample_id, workflow_id, status, sequencer_run_id, lane_id, ius_id)
						VALUES (_study_id, _sample_id, _workflow_id, _new_status, _sequencer_run_id, _lane_id, _ius_id);
					END IF;
				END IF;
			END LOOP;
		END LOOP;
	END LOOP;
  END LOOP;
  RETURN TRUE;
END;$$;


ALTER FUNCTION public.fill_sample_report() OWNER TO seqware;

--
-- Name: expense_expense_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE expense_expense_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.expense_expense_id_seq OWNER TO seqware;

--
-- Name: expense_expense_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('expense_expense_id_seq', 1, false);


--
-- Name: sw_accession_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE sw_accession_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sw_accession_seq OWNER TO seqware;

--
-- Name: sw_accession_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('sw_accession_seq', 82, true);


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: expense; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE expense (
    expense_id integer DEFAULT nextval('expense_expense_id_seq'::regclass) NOT NULL,
    invoice_id integer NOT NULL,
    workflow_run_id integer,
    agent text,
    expense_type text,
    description text,
    price_per_unit numeric,
    total_units numeric,
    total_price numeric,
    added_surcharge numeric,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    expense_finished_tstmp timestamp without time zone
);


ALTER TABLE public.expense OWNER TO seqware;

--
-- Name: expense_attribute_expense_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE expense_attribute_expense_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.expense_attribute_expense_attribute_id_seq OWNER TO seqware;

--
-- Name: expense_attribute_expense_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('expense_attribute_expense_attribute_id_seq', 1, false);


--
-- Name: expense_attribute; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE expense_attribute (
    expense_attribute_id integer DEFAULT nextval('expense_attribute_expense_attribute_id_seq'::regclass) NOT NULL,
    expense_id integer NOT NULL,
    tag text,
    value text,
    units text
);


ALTER TABLE public.expense_attribute OWNER TO seqware;

--
-- Name: experiment; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE experiment (
    experiment_id integer NOT NULL,
    study_id integer NOT NULL,
    experiment_library_design_id integer,
    experiment_spot_design_id integer,
    platform_id integer,
    name text,
    title text,
    description text,
    alias text,
    accession text,
    status text,
    center_name text,
    sequence_space text,
    base_caller text,
    quality_scorer text,
    quality_number_of_levels integer,
    quality_multiplier integer,
    quality_type text,
    expected_number_runs integer,
    expected_number_spots bigint,
    expected_number_reads bigint,
    owner_id integer,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone,
    CONSTRAINT experiment_quality_type_check CHECK ((quality_type = ANY (ARRAY['phred'::text, 'other'::text]))),
    CONSTRAINT experiment_sequence_space_check CHECK ((sequence_space = ANY (ARRAY['Base Space'::text, 'Color Space'::text])))
);


ALTER TABLE public.experiment OWNER TO seqware;

--
-- Name: experiment_attribute; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE experiment_attribute (
    experiment_attribute_id integer NOT NULL,
    experiment_id integer NOT NULL,
    tag text,
    value text,
    units text
);


ALTER TABLE public.experiment_attribute OWNER TO seqware;

--
-- Name: experiment_attribute_experiment_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE experiment_attribute_experiment_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.experiment_attribute_experiment_attribute_id_seq OWNER TO seqware;

--
-- Name: experiment_attribute_experiment_attribute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE experiment_attribute_experiment_attribute_id_seq OWNED BY experiment_attribute.experiment_attribute_id;


--
-- Name: experiment_attribute_experiment_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('experiment_attribute_experiment_attribute_id_seq', 1, false);


--
-- Name: experiment_experiment_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE experiment_experiment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.experiment_experiment_id_seq OWNER TO seqware;

--
-- Name: experiment_experiment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE experiment_experiment_id_seq OWNED BY experiment.experiment_id;


--
-- Name: experiment_experiment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('experiment_experiment_id_seq', 1, true);


--
-- Name: experiment_library_design; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE experiment_library_design (
    experiment_library_design_id integer NOT NULL,
    name text,
    description text,
    construction_protocol text,
    strategy integer,
    source integer,
    selection integer,
    layout text,
    paired_orientation text,
    nominal_length integer,
    nominal_sdev double precision,
    CONSTRAINT experiment_library_design_layout_check CHECK ((layout = ANY (ARRAY['paired'::text, 'single'::text])))
);


ALTER TABLE public.experiment_library_design OWNER TO seqware;

--
-- Name: experiment_library_design_experiment_library_design_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE experiment_library_design_experiment_library_design_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.experiment_library_design_experiment_library_design_id_seq OWNER TO seqware;

--
-- Name: experiment_library_design_experiment_library_design_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE experiment_library_design_experiment_library_design_id_seq OWNED BY experiment_library_design.experiment_library_design_id;


--
-- Name: experiment_library_design_experiment_library_design_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('experiment_library_design_experiment_library_design_id_seq', 1, false);


--
-- Name: experiment_link; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE experiment_link (
    experiment_link_id integer NOT NULL,
    experiment_id integer NOT NULL,
    label text,
    url text,
    db text,
    id text
);


ALTER TABLE public.experiment_link OWNER TO seqware;

--
-- Name: experiment_link_experiment_link_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE experiment_link_experiment_link_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.experiment_link_experiment_link_id_seq OWNER TO seqware;

--
-- Name: experiment_link_experiment_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE experiment_link_experiment_link_id_seq OWNED BY experiment_link.experiment_link_id;


--
-- Name: experiment_link_experiment_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('experiment_link_experiment_link_id_seq', 1, false);


--
-- Name: experiment_spot_design; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE experiment_spot_design (
    experiment_spot_design_id integer NOT NULL,
    decode_method integer,
    reads_per_spot integer,
    read_spec text,
    tag_spec text,
    adapter_spec text
);


ALTER TABLE public.experiment_spot_design OWNER TO seqware;

--
-- Name: experiment_spot_design_experiment_spot_design_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE experiment_spot_design_experiment_spot_design_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.experiment_spot_design_experiment_spot_design_id_seq OWNER TO seqware;

--
-- Name: experiment_spot_design_experiment_spot_design_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE experiment_spot_design_experiment_spot_design_id_seq OWNED BY experiment_spot_design.experiment_spot_design_id;


--
-- Name: experiment_spot_design_experiment_spot_design_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('experiment_spot_design_experiment_spot_design_id_seq', 1, false);


--
-- Name: experiment_spot_design_read_spec; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE experiment_spot_design_read_spec (
    experiment_spot_design_read_spec_id integer NOT NULL,
    experiment_spot_design_id integer,
    read_index integer,
    read_label text,
    read_class text,
    read_type text,
    base_coord integer,
    cycle_coord integer,
    length integer,
    expected_basecall text,
    CONSTRAINT read_class_ck CHECK ((read_class = ANY (ARRAY[('Technical Read'::character varying)::text, ('Application Read'::character varying)::text]))),
    CONSTRAINT read_type_ck CHECK ((read_type = ANY (ARRAY[('Forward'::character varying)::text, ('Reverse'::character varying)::text, ('Adapter'::character varying)::text, ('Primer'::character varying)::text, ('Linker'::character varying)::text, ('BarCode'::character varying)::text, ('Other'::character varying)::text])))
);


ALTER TABLE public.experiment_spot_design_read_spec OWNER TO seqware;

--
-- Name: experiment_spot_design_read_s_experiment_spot_design_read_s_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE experiment_spot_design_read_s_experiment_spot_design_read_s_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.experiment_spot_design_read_s_experiment_spot_design_read_s_seq OWNER TO seqware;

--
-- Name: experiment_spot_design_read_s_experiment_spot_design_read_s_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE experiment_spot_design_read_s_experiment_spot_design_read_s_seq OWNED BY experiment_spot_design_read_spec.experiment_spot_design_read_spec_id;


--
-- Name: experiment_spot_design_read_s_experiment_spot_design_read_s_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('experiment_spot_design_read_s_experiment_spot_design_read_s_seq', 1, false);


--
-- Name: file; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE file (
    file_id integer NOT NULL,
    file_path text NOT NULL,
    md5sum text,
    url text,
    url_label text,
    type text,
    meta_type text,
    description text,
    owner_id integer,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    file_type_id integer,
    size bigint
);


ALTER TABLE public.file OWNER TO seqware;

--
-- Name: file_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE file_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.file_attribute_id_seq OWNER TO seqware;

--
-- Name: file_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('file_attribute_id_seq', 1, false);


--
-- Name: file_attribute; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE file_attribute (
    file_attribute_id integer DEFAULT nextval('file_attribute_id_seq'::regclass) NOT NULL,
    file_id integer NOT NULL,
    tag character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    unit character varying(255)
);


ALTER TABLE public.file_attribute OWNER TO seqware;

--
-- Name: file_file_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE file_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.file_file_id_seq OWNER TO seqware;

--
-- Name: file_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE file_file_id_seq OWNED BY file.file_id;


--
-- Name: file_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('file_file_id_seq', 1, false);


--
-- Name: file_report; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE file_report (
    row_id integer NOT NULL,
    study_id integer,
    ius_id integer,
    lane_id integer,
    file_id integer,
    sample_id integer,
    experiment_id integer,
    child_sample_id integer,
    processing_id integer
);


ALTER TABLE public.file_report OWNER TO seqware;

--
-- Name: file_report_row_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE file_report_row_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.file_report_row_id_seq OWNER TO seqware;

--
-- Name: file_report_row_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE file_report_row_id_seq OWNED BY file_report.row_id;


--
-- Name: file_report_row_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('file_report_row_id_seq', 1, false);


--
-- Name: file_type; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE file_type (
    file_type_id integer NOT NULL,
    display_name text,
    meta_type text,
    extension text
);


ALTER TABLE public.file_type OWNER TO seqware;

--
-- Name: file_type_file_type_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE file_type_file_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.file_type_file_type_id_seq OWNER TO seqware;

--
-- Name: file_type_file_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE file_type_file_type_id_seq OWNED BY file_type.file_type_id;


--
-- Name: file_type_file_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('file_type_file_type_id_seq', 4, true);


--
-- Name: invoice_invoice_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE invoice_invoice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.invoice_invoice_id_seq OWNER TO seqware;

--
-- Name: invoice_invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('invoice_invoice_id_seq', 1, false);


--
-- Name: invoice; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE invoice (
    invoice_id integer DEFAULT nextval('invoice_invoice_id_seq'::regclass) NOT NULL,
    owner_id integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    state text,
    finalized boolean,
    fully_paid boolean,
    paid_amount numeric,
    days_until_due integer,
    external_id text,
    client_notes text,
    notes text,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    create_tstmp timestamp without time zone NOT NULL
);


ALTER TABLE public.invoice OWNER TO seqware;

--
-- Name: invoice_attribute_invoice_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE invoice_attribute_invoice_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.invoice_attribute_invoice_attribute_id_seq OWNER TO seqware;

--
-- Name: invoice_attribute_invoice_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('invoice_attribute_invoice_attribute_id_seq', 1, false);


--
-- Name: invoice_attribute; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE invoice_attribute (
    invoice_attribute_id integer DEFAULT nextval('invoice_attribute_invoice_attribute_id_seq'::regclass) NOT NULL,
    invoice_id integer NOT NULL,
    tag text,
    value text,
    units text
);


ALTER TABLE public.invoice_attribute OWNER TO seqware;

--
-- Name: ius; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE ius (
    ius_id integer NOT NULL,
    sample_id integer NOT NULL,
    lane_id integer NOT NULL,
    owner_id integer,
    name text,
    alias text,
    description text,
    tag text,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone,
    skip boolean DEFAULT false
);


ALTER TABLE public.ius OWNER TO seqware;

--
-- Name: ius_attribute; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE ius_attribute (
    ius_attribute_id integer NOT NULL,
    ius_id integer NOT NULL,
    tag text,
    value text,
    units text
);


ALTER TABLE public.ius_attribute OWNER TO seqware;

--
-- Name: ius_attribute_ius_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE ius_attribute_ius_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ius_attribute_ius_attribute_id_seq OWNER TO seqware;

--
-- Name: ius_attribute_ius_attribute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE ius_attribute_ius_attribute_id_seq OWNED BY ius_attribute.ius_attribute_id;


--
-- Name: ius_attribute_ius_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('ius_attribute_ius_attribute_id_seq', 2, true);


--
-- Name: ius_ius_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE ius_ius_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ius_ius_id_seq OWNER TO seqware;

--
-- Name: ius_ius_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE ius_ius_id_seq OWNED BY ius.ius_id;


--
-- Name: ius_ius_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('ius_ius_id_seq', 22, true);


--
-- Name: ius_link; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE ius_link (
    ius_link_id integer NOT NULL,
    ius_id integer NOT NULL,
    label text NOT NULL,
    url text NOT NULL,
    db text,
    id text
);


ALTER TABLE public.ius_link OWNER TO seqware;

--
-- Name: ius_link_ius_link_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE ius_link_ius_link_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ius_link_ius_link_id_seq OWNER TO seqware;

--
-- Name: ius_link_ius_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE ius_link_ius_link_id_seq OWNED BY ius_link.ius_link_id;


--
-- Name: ius_link_ius_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('ius_link_ius_link_id_seq', 1, false);


--
-- Name: ius_workflow_runs; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE ius_workflow_runs (
    ius_workflow_runs_id integer NOT NULL,
    ius_id integer NOT NULL,
    workflow_run_id integer NOT NULL
);


ALTER TABLE public.ius_workflow_runs OWNER TO seqware;

--
-- Name: ius_workflow_runs_ius_workflow_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE ius_workflow_runs_ius_workflow_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.ius_workflow_runs_ius_workflow_runs_id_seq OWNER TO seqware;

--
-- Name: ius_workflow_runs_ius_workflow_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE ius_workflow_runs_ius_workflow_runs_id_seq OWNED BY ius_workflow_runs.ius_workflow_runs_id;


--
-- Name: ius_workflow_runs_ius_workflow_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('ius_workflow_runs_ius_workflow_runs_id_seq', 1, false);


--
-- Name: lane; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE lane (
    lane_id integer NOT NULL,
    sequencer_run_id integer,
    sample_id integer,
    organism_id integer,
    name text,
    alias text,
    description text,
    lane_index integer,
    cycle_descriptor text,
    cycle_count integer,
    cycle_sequence text,
    type integer,
    study_type integer,
    library_strategy integer,
    library_selection integer,
    library_source integer,
    skip boolean DEFAULT false,
    tags text,
    regions text,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    owner_id integer,
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone
);


ALTER TABLE public.lane OWNER TO seqware;

--
-- Name: lane_attribute; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE lane_attribute (
    lane_attribute_id integer NOT NULL,
    lane_id integer NOT NULL,
    tag text,
    value text,
    units text
);


ALTER TABLE public.lane_attribute OWNER TO seqware;

--
-- Name: lane_attribute_lane_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE lane_attribute_lane_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.lane_attribute_lane_attribute_id_seq OWNER TO seqware;

--
-- Name: lane_attribute_lane_attribute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE lane_attribute_lane_attribute_id_seq OWNED BY lane_attribute.lane_attribute_id;


--
-- Name: lane_attribute_lane_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('lane_attribute_lane_attribute_id_seq', 21, true);


--
-- Name: lane_lane_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE lane_lane_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.lane_lane_id_seq OWNER TO seqware;

--
-- Name: lane_lane_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE lane_lane_id_seq OWNED BY lane.lane_id;


--
-- Name: lane_lane_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('lane_lane_id_seq', 18, true);


--
-- Name: lane_link; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE lane_link (
    lane_link_id integer NOT NULL,
    lane_id integer NOT NULL,
    label text NOT NULL,
    url text NOT NULL,
    db text,
    id text
);


ALTER TABLE public.lane_link OWNER TO seqware;

--
-- Name: lane_link_lane_link_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE lane_link_lane_link_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.lane_link_lane_link_id_seq OWNER TO seqware;

--
-- Name: lane_link_lane_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE lane_link_lane_link_id_seq OWNED BY lane_link.lane_link_id;


--
-- Name: lane_link_lane_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('lane_link_lane_link_id_seq', 1, false);


--
-- Name: lane_type; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE lane_type (
    lane_type_id integer NOT NULL,
    code text,
    name text
);


ALTER TABLE public.lane_type OWNER TO seqware;

--
-- Name: lane_type_lane_type_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE lane_type_lane_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.lane_type_lane_type_id_seq OWNER TO seqware;

--
-- Name: lane_type_lane_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE lane_type_lane_type_id_seq OWNED BY lane_type.lane_type_id;


--
-- Name: lane_type_lane_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('lane_type_lane_type_id_seq', 7, true);


--
-- Name: lane_workflow_runs; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE lane_workflow_runs (
    lane_workflow_runs_id integer NOT NULL,
    lane_id integer NOT NULL,
    workflow_run_id integer NOT NULL
);


ALTER TABLE public.lane_workflow_runs OWNER TO seqware;

--
-- Name: lane_workflow_runs_lane_workflow_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE lane_workflow_runs_lane_workflow_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.lane_workflow_runs_lane_workflow_runs_id_seq OWNER TO seqware;

--
-- Name: lane_workflow_runs_lane_workflow_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE lane_workflow_runs_lane_workflow_runs_id_seq OWNED BY lane_workflow_runs.lane_workflow_runs_id;


--
-- Name: lane_workflow_runs_lane_workflow_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('lane_workflow_runs_lane_workflow_runs_id_seq', 1, false);


--
-- Name: library_selection; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE library_selection (
    library_selection_id integer NOT NULL,
    name text,
    description text
);


ALTER TABLE public.library_selection OWNER TO seqware;

--
-- Name: library_selection_library_selection_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE library_selection_library_selection_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.library_selection_library_selection_id_seq OWNER TO seqware;

--
-- Name: library_selection_library_selection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE library_selection_library_selection_id_seq OWNED BY library_selection.library_selection_id;


--
-- Name: library_selection_library_selection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('library_selection_library_selection_id_seq', 25, true);


--
-- Name: library_source; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE library_source (
    library_source_id integer NOT NULL,
    name text,
    description text
);


ALTER TABLE public.library_source OWNER TO seqware;

--
-- Name: library_source_library_source_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE library_source_library_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.library_source_library_source_id_seq OWNER TO seqware;

--
-- Name: library_source_library_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE library_source_library_source_id_seq OWNED BY library_source.library_source_id;


--
-- Name: library_source_library_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('library_source_library_source_id_seq', 7, true);


--
-- Name: library_strategy; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE library_strategy (
    library_strategy_id integer NOT NULL,
    name text,
    description text
);


ALTER TABLE public.library_strategy OWNER TO seqware;

--
-- Name: library_strategy_library_strategy_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE library_strategy_library_strategy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.library_strategy_library_strategy_id_seq OWNER TO seqware;

--
-- Name: library_strategy_library_strategy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE library_strategy_library_strategy_id_seq OWNED BY library_strategy.library_strategy_id;


--
-- Name: library_strategy_library_strategy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('library_strategy_library_strategy_id_seq', 21, true);


--
-- Name: organism; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE organism (
    organism_id integer NOT NULL,
    code text NOT NULL,
    name text,
    accession text,
    ncbi_taxid integer
);


ALTER TABLE public.organism OWNER TO seqware;

--
-- Name: organism_organism_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE organism_organism_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.organism_organism_id_seq OWNER TO seqware;

--
-- Name: organism_organism_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE organism_organism_id_seq OWNED BY organism.organism_id;


--
-- Name: organism_organism_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('organism_organism_id_seq', 56, true);


--
-- Name: platform; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE platform (
    platform_id integer NOT NULL,
    name text,
    instrument_model text,
    description text
);


ALTER TABLE public.platform OWNER TO seqware;

--
-- Name: platform_platform_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE platform_platform_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.platform_platform_id_seq OWNER TO seqware;

--
-- Name: platform_platform_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE platform_platform_id_seq OWNED BY platform.platform_id;


--
-- Name: platform_platform_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('platform_platform_id_seq', 28, true);


--
-- Name: processing; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE processing (
    processing_id integer NOT NULL,
    workflow_run_id integer,
    ancestor_workflow_run_id integer,
    algorithm text,
    status text,
    description text,
    url text,
    url_label text,
    version text,
    parameters text,
    stdout text,
    stderr text,
    exit_status integer,
    process_exit_status integer,
    task_group boolean DEFAULT false,
    owner_id integer,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    run_start_tstmp timestamp without time zone,
    run_stop_tstmp timestamp without time zone,
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone
);


ALTER TABLE public.processing OWNER TO seqware;

--
-- Name: processing_attribute; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE processing_attribute (
    processing_attribute_id integer NOT NULL,
    processing_id integer NOT NULL,
    tag text,
    value text,
    units text
);


ALTER TABLE public.processing_attribute OWNER TO seqware;

--
-- Name: processing_attribute_processing_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE processing_attribute_processing_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.processing_attribute_processing_attribute_id_seq OWNER TO seqware;

--
-- Name: processing_attribute_processing_attribute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE processing_attribute_processing_attribute_id_seq OWNED BY processing_attribute.processing_attribute_id;


--
-- Name: processing_attribute_processing_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('processing_attribute_processing_attribute_id_seq', 1, false);


--
-- Name: processing_experiments; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE processing_experiments (
    processing_experiments_id integer NOT NULL,
    experiment_id integer NOT NULL,
    processing_id integer NOT NULL,
    description text,
    label text,
    url text,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass)
);


ALTER TABLE public.processing_experiments OWNER TO seqware;

--
-- Name: processing_experiments_processing_experiments_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE processing_experiments_processing_experiments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.processing_experiments_processing_experiments_id_seq OWNER TO seqware;

--
-- Name: processing_experiments_processing_experiments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE processing_experiments_processing_experiments_id_seq OWNED BY processing_experiments.processing_experiments_id;


--
-- Name: processing_experiments_processing_experiments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('processing_experiments_processing_experiments_id_seq', 1, false);


--
-- Name: processing_files; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE processing_files (
    processing_files_id integer NOT NULL,
    processing_id integer NOT NULL,
    file_id integer NOT NULL
);


ALTER TABLE public.processing_files OWNER TO seqware;

--
-- Name: processing_files_processing_files_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE processing_files_processing_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.processing_files_processing_files_id_seq OWNER TO seqware;

--
-- Name: processing_files_processing_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE processing_files_processing_files_id_seq OWNED BY processing_files.processing_files_id;


--
-- Name: processing_files_processing_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('processing_files_processing_files_id_seq', 1, false);


--
-- Name: processing_ius; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE processing_ius (
    processing_ius_id integer NOT NULL,
    ius_id integer NOT NULL,
    processing_id integer NOT NULL,
    description text,
    label text,
    url text,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass)
);


ALTER TABLE public.processing_ius OWNER TO seqware;

--
-- Name: processing_ius_processing_ius_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE processing_ius_processing_ius_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.processing_ius_processing_ius_id_seq OWNER TO seqware;

--
-- Name: processing_ius_processing_ius_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE processing_ius_processing_ius_id_seq OWNED BY processing_ius.processing_ius_id;


--
-- Name: processing_ius_processing_ius_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('processing_ius_processing_ius_id_seq', 1, false);


--
-- Name: processing_lanes; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE processing_lanes (
    processing_lanes_id integer NOT NULL,
    lane_id integer NOT NULL,
    processing_id integer NOT NULL,
    description text,
    label text,
    url text,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass)
);


ALTER TABLE public.processing_lanes OWNER TO seqware;

--
-- Name: processing_lanes_processing_lanes_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE processing_lanes_processing_lanes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.processing_lanes_processing_lanes_id_seq OWNER TO seqware;

--
-- Name: processing_lanes_processing_lanes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE processing_lanes_processing_lanes_id_seq OWNED BY processing_lanes.processing_lanes_id;


--
-- Name: processing_lanes_processing_lanes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('processing_lanes_processing_lanes_id_seq', 1, false);


--
-- Name: processing_processing_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE processing_processing_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.processing_processing_id_seq OWNER TO seqware;

--
-- Name: processing_processing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE processing_processing_id_seq OWNED BY processing.processing_id;


--
-- Name: processing_processing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('processing_processing_id_seq', 1, false);


--
-- Name: processing_relationship; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE processing_relationship (
    processing_relationship_id integer NOT NULL,
    parent_id integer,
    child_id integer,
    relationship text
);


ALTER TABLE public.processing_relationship OWNER TO seqware;

--
-- Name: processing_relationship_processing_relationship_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE processing_relationship_processing_relationship_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.processing_relationship_processing_relationship_id_seq OWNER TO seqware;

--
-- Name: processing_relationship_processing_relationship_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE processing_relationship_processing_relationship_id_seq OWNED BY processing_relationship.processing_relationship_id;


--
-- Name: processing_relationship_processing_relationship_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('processing_relationship_processing_relationship_id_seq', 1, false);


--
-- Name: processing_samples; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE processing_samples (
    processing_samples_id integer NOT NULL,
    sample_id integer NOT NULL,
    processing_id integer NOT NULL,
    description text,
    label text,
    url text,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass)
);


ALTER TABLE public.processing_samples OWNER TO seqware;

--
-- Name: processing_samples_processing_samples_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE processing_samples_processing_samples_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.processing_samples_processing_samples_id_seq OWNER TO seqware;

--
-- Name: processing_samples_processing_samples_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE processing_samples_processing_samples_id_seq OWNED BY processing_samples.processing_samples_id;


--
-- Name: processing_samples_processing_samples_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('processing_samples_processing_samples_id_seq', 1, false);


--
-- Name: processing_sequencer_runs; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE processing_sequencer_runs (
    processing_sequencer_runs_id integer NOT NULL,
    sequencer_run_id integer NOT NULL,
    processing_id integer NOT NULL,
    description text,
    label text,
    url text,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass)
);


ALTER TABLE public.processing_sequencer_runs OWNER TO seqware;

--
-- Name: processing_sequencer_runs_processing_sequencer_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE processing_sequencer_runs_processing_sequencer_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.processing_sequencer_runs_processing_sequencer_runs_id_seq OWNER TO seqware;

--
-- Name: processing_sequencer_runs_processing_sequencer_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE processing_sequencer_runs_processing_sequencer_runs_id_seq OWNED BY processing_sequencer_runs.processing_sequencer_runs_id;


--
-- Name: processing_sequencer_runs_processing_sequencer_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('processing_sequencer_runs_processing_sequencer_runs_id_seq', 1, false);


--
-- Name: processing_studies; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE processing_studies (
    processing_studies_id integer NOT NULL,
    study_id integer NOT NULL,
    processing_id integer NOT NULL,
    description text,
    label text,
    url text,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass)
);


ALTER TABLE public.processing_studies OWNER TO seqware;

--
-- Name: processing_studies_processing_studies_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE processing_studies_processing_studies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.processing_studies_processing_studies_id_seq OWNER TO seqware;

--
-- Name: processing_studies_processing_studies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE processing_studies_processing_studies_id_seq OWNED BY processing_studies.processing_studies_id;


--
-- Name: processing_studies_processing_studies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('processing_studies_processing_studies_id_seq', 1, false);


--
-- Name: registration; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE registration (
    registration_id integer NOT NULL,
    email text NOT NULL,
    password text,
    password_hint text,
    first_name text NOT NULL,
    last_name text NOT NULL,
    institution text,
    invitation_code text,
    lims_admin boolean DEFAULT false NOT NULL,
    create_tstmp timestamp without time zone NOT NULL,
    last_update_tstmp timestamp without time zone NOT NULL,
    developer_ml boolean DEFAULT false NOT NULL,
    user_ml boolean DEFAULT false NOT NULL,
    payee boolean DEFAULT false NOT NULL
);


ALTER TABLE public.registration OWNER TO seqware;

--
-- Name: registration_registration_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE registration_registration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.registration_registration_id_seq OWNER TO seqware;

--
-- Name: registration_registration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE registration_registration_id_seq OWNED BY registration.registration_id;


--
-- Name: registration_registration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('registration_registration_id_seq', 4, true);


--
-- Name: sample; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE sample (
    sample_id integer NOT NULL,
    experiment_id integer,
    organism_id integer,
    name text,
    title text,
    alias text,
    type text,
    scientific_name text,
    common_name text,
    anonymized_name text,
    individual_name text,
    description text,
    taxon_id integer,
    tags text,
    adapters text,
    regions text,
    expected_number_runs integer,
    expected_number_spots integer,
    expected_number_reads integer,
    skip boolean,
    is_public boolean,
    owner_id integer,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone
);


ALTER TABLE public.sample OWNER TO seqware;

--
-- Name: sample_attribute; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE sample_attribute (
    sample_attribute_id integer NOT NULL,
    sample_id integer NOT NULL,
    tag text NOT NULL,
    value text NOT NULL,
    units text
);


ALTER TABLE public.sample_attribute OWNER TO seqware;

--
-- Name: sample_attribute_sample_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE sample_attribute_sample_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sample_attribute_sample_attribute_id_seq OWNER TO seqware;

--
-- Name: sample_attribute_sample_attribute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE sample_attribute_sample_attribute_id_seq OWNED BY sample_attribute.sample_attribute_id;


--
-- Name: sample_attribute_sample_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('sample_attribute_sample_attribute_id_seq', 110, true);


--
-- Name: sample_hierarchy; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE sample_hierarchy (
    sample_id integer NOT NULL,
    parent_id integer
);


ALTER TABLE public.sample_hierarchy OWNER TO seqware;

--
-- Name: TABLE sample_hierarchy; Type: COMMENT; Schema: public; Owner: seqware
--

COMMENT ON TABLE sample_hierarchy IS 'Relationship of samples as they pass through the wet lab.';


--
-- Name: sample_link; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE sample_link (
    sample_link_id integer NOT NULL,
    sample_id integer NOT NULL,
    label text NOT NULL,
    url text NOT NULL,
    db text,
    id text
);


ALTER TABLE public.sample_link OWNER TO seqware;

--
-- Name: sample_link_sample_link_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE sample_link_sample_link_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sample_link_sample_link_id_seq OWNER TO seqware;

--
-- Name: sample_link_sample_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE sample_link_sample_link_id_seq OWNED BY sample_link.sample_link_id;


--
-- Name: sample_link_sample_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('sample_link_sample_link_id_seq', 1, false);


--
-- Name: sample_relationship; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE sample_relationship (
    sample_relationship_id integer NOT NULL,
    parent_id integer,
    child_id integer,
    relationship text
);


ALTER TABLE public.sample_relationship OWNER TO seqware;

--
-- Name: sample_relationship_sample_relationship_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE sample_relationship_sample_relationship_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sample_relationship_sample_relationship_id_seq OWNER TO seqware;

--
-- Name: sample_relationship_sample_relationship_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE sample_relationship_sample_relationship_id_seq OWNED BY sample_relationship.sample_relationship_id;


--
-- Name: sample_relationship_sample_relationship_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('sample_relationship_sample_relationship_id_seq', 1, false);


--
-- Name: sample_report; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE sample_report (
    study_id integer,
    child_sample_id integer,
    workflow_id integer,
    status character varying(255),
    sequencer_run_id integer,
    lane_id integer,
    ius_id integer,
    row_id integer NOT NULL
);


ALTER TABLE public.sample_report OWNER TO seqware;

--
-- Name: sample_report_row_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE sample_report_row_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sample_report_row_id_seq OWNER TO seqware;

--
-- Name: sample_report_row_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE sample_report_row_id_seq OWNED BY sample_report.row_id;


--
-- Name: sample_report_row_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('sample_report_row_id_seq', 1, false);


--
-- Name: sample_sample_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE sample_sample_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sample_sample_id_seq OWNER TO seqware;

--
-- Name: sample_sample_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE sample_sample_id_seq OWNED BY sample.sample_id;


--
-- Name: sample_sample_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('sample_sample_id_seq', 37, true);


--
-- Name: sample_search_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE sample_search_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sample_search_id_seq OWNER TO seqware;

--
-- Name: sample_search_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('sample_search_id_seq', 1, false);


--
-- Name: sample_search; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE sample_search (
    sample_search_id integer DEFAULT nextval('sample_search_id_seq'::regclass) NOT NULL,
    sample_id integer NOT NULL,
    create_tstmp timestamp without time zone NOT NULL
);


ALTER TABLE public.sample_search OWNER TO seqware;

--
-- Name: sample_search_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE sample_search_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sample_search_attribute_id_seq OWNER TO seqware;

--
-- Name: sample_search_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('sample_search_attribute_id_seq', 1, false);


--
-- Name: sample_search_attribute; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE sample_search_attribute (
    sample_search_attribute_id integer DEFAULT nextval('sample_search_attribute_id_seq'::regclass) NOT NULL,
    sample_search_id integer NOT NULL,
    tag character varying(255) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.sample_search_attribute OWNER TO seqware;

--
-- Name: sequencer_run; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE sequencer_run (
    sequencer_run_id integer NOT NULL,
    name text,
    description text,
    status text,
    platform_id integer,
    instrument_name text,
    cycle_descriptor text,
    cycle_count integer,
    cycle_sequence text,
    file_path text,
    paired_end boolean,
    process boolean,
    ref_lane integer,
    paired_file_path text,
    use_ipar_intensities boolean,
    color_matrix text,
    color_matrix_code text,
    slide_count integer,
    slide_1_lane_count integer,
    slide_1_file_path text,
    slide_2_lane_count integer,
    slide_2_file_path text,
    flow_sequence text,
    flow_count integer,
    owner_id integer,
    run_center text,
    base_caller text,
    quality_scorer text,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone,
    skip boolean DEFAULT false
);


ALTER TABLE public.sequencer_run OWNER TO seqware;

--
-- Name: sequencer_run_attribute; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE sequencer_run_attribute (
    sequencer_run_attribute_id integer NOT NULL,
    sample_id integer NOT NULL,
    tag text NOT NULL,
    value text NOT NULL,
    units text
);


ALTER TABLE public.sequencer_run_attribute OWNER TO seqware;

--
-- Name: sequencer_run_attribute_sequencer_run_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE sequencer_run_attribute_sequencer_run_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sequencer_run_attribute_sequencer_run_attribute_id_seq OWNER TO seqware;

--
-- Name: sequencer_run_attribute_sequencer_run_attribute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE sequencer_run_attribute_sequencer_run_attribute_id_seq OWNED BY sequencer_run_attribute.sequencer_run_attribute_id;


--
-- Name: sequencer_run_attribute_sequencer_run_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('sequencer_run_attribute_sequencer_run_attribute_id_seq', 1, true);


--
-- Name: sequencer_run_sequencer_run_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE sequencer_run_sequencer_run_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.sequencer_run_sequencer_run_id_seq OWNER TO seqware;

--
-- Name: sequencer_run_sequencer_run_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE sequencer_run_sequencer_run_id_seq OWNED BY sequencer_run.sequencer_run_id;


--
-- Name: sequencer_run_sequencer_run_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('sequencer_run_sequencer_run_id_seq', 3, true);


--
-- Name: share_experiment; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE share_experiment (
    share_experiment_id integer NOT NULL,
    experiment_id integer NOT NULL,
    registration_id integer NOT NULL,
    active boolean DEFAULT true,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone
);


ALTER TABLE public.share_experiment OWNER TO seqware;

--
-- Name: share_file; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE share_file (
    file_id integer NOT NULL,
    registration_id integer NOT NULL,
    active boolean DEFAULT true,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone,
    share_file_id integer NOT NULL
);


ALTER TABLE public.share_file OWNER TO seqware;

--
-- Name: share_lane; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE share_lane (
    lane_id integer NOT NULL,
    registration_id integer NOT NULL,
    active boolean DEFAULT true,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone,
    share_lane_id integer NOT NULL
);


ALTER TABLE public.share_lane OWNER TO seqware;

--
-- Name: share_processing; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE share_processing (
    processing_id integer NOT NULL,
    registration_id integer NOT NULL,
    active boolean DEFAULT true,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone,
    share_processing_id integer NOT NULL
);


ALTER TABLE public.share_processing OWNER TO seqware;

--
-- Name: share_sample; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE share_sample (
    sample_id integer NOT NULL,
    registration_id integer NOT NULL,
    active boolean DEFAULT true,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone,
    share_sample_id integer NOT NULL
);


ALTER TABLE public.share_sample OWNER TO seqware;

--
-- Name: share_study; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE share_study (
    share_study_id integer NOT NULL,
    study_id integer NOT NULL,
    registration_id integer NOT NULL,
    active boolean DEFAULT true,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone
);


ALTER TABLE public.share_study OWNER TO seqware;

--
-- Name: share_study_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE share_study_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.share_study_id_seq OWNER TO seqware;

--
-- Name: share_study_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE share_study_id_seq OWNED BY share_study.share_study_id;


--
-- Name: share_study_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('share_study_id_seq', 1, false);


--
-- Name: share_workflow_run; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE share_workflow_run (
    share_workflow_run_id integer NOT NULL,
    workflow_run_id integer NOT NULL,
    registration_id integer NOT NULL,
    active boolean DEFAULT true,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone
);


ALTER TABLE public.share_workflow_run OWNER TO seqware;

--
-- Name: share_workflow_run_share_workflow_run_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE share_workflow_run_share_workflow_run_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.share_workflow_run_share_workflow_run_id_seq OWNER TO seqware;

--
-- Name: share_workflow_run_share_workflow_run_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE share_workflow_run_share_workflow_run_id_seq OWNED BY share_workflow_run.share_workflow_run_id;


--
-- Name: share_workflow_run_share_workflow_run_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('share_workflow_run_share_workflow_run_id_seq', 1, false);


--
-- Name: study; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE study (
    study_id integer NOT NULL,
    title text NOT NULL,
    alias text,
    description text,
    accession text,
    abstract text,
    existing_type integer NOT NULL,
    new_type text,
    center_name text NOT NULL,
    center_project_name text NOT NULL,
    project_id integer DEFAULT 0 NOT NULL,
    status text,
    owner_id integer,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone
);


ALTER TABLE public.study OWNER TO seqware;

--
-- Name: study_attribute; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE study_attribute (
    study_attribute_id integer NOT NULL,
    study_id integer NOT NULL,
    tag text NOT NULL,
    value text NOT NULL,
    units text
);


ALTER TABLE public.study_attribute OWNER TO seqware;

--
-- Name: study_attribute_study_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE study_attribute_study_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.study_attribute_study_attribute_id_seq OWNER TO seqware;

--
-- Name: study_attribute_study_attribute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE study_attribute_study_attribute_id_seq OWNED BY study_attribute.study_attribute_id;


--
-- Name: study_attribute_study_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('study_attribute_study_attribute_id_seq', 1, false);


--
-- Name: study_link; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE study_link (
    study_link_id integer NOT NULL,
    study_id integer NOT NULL,
    label text NOT NULL,
    url text NOT NULL,
    db text,
    id text
);


ALTER TABLE public.study_link OWNER TO seqware;

--
-- Name: study_link_study_link_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE study_link_study_link_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.study_link_study_link_id_seq OWNER TO seqware;

--
-- Name: study_link_study_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE study_link_study_link_id_seq OWNED BY study_link.study_link_id;


--
-- Name: study_link_study_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('study_link_study_link_id_seq', 1, false);


--
-- Name: study_study_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE study_study_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.study_study_id_seq OWNER TO seqware;

--
-- Name: study_study_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE study_study_id_seq OWNED BY study.study_id;


--
-- Name: study_study_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('study_study_id_seq', 1, true);


--
-- Name: study_type; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE study_type (
    study_type_id integer NOT NULL,
    name text NOT NULL,
    description text
);


ALTER TABLE public.study_type OWNER TO seqware;

--
-- Name: study_type_study_type_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE study_type_study_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.study_type_study_type_id_seq OWNER TO seqware;

--
-- Name: study_type_study_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE study_type_study_type_id_seq OWNED BY study_type.study_type_id;


--
-- Name: study_type_study_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('study_type_study_type_id_seq', 11, true);


--
-- Name: version; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE version (
    version_id integer NOT NULL,
    name text,
    major integer,
    minor integer,
    bugfix integer,
    type character varying(100),
    CONSTRAINT lims_version_release_type_ck CHECK (((type)::text = ANY (ARRAY[(''::character varying)::text, ('rc'::character varying)::text, ('alpha'::character varying)::text, ('beta'::character varying)::text, ('debug'::character varying)::text])))
);


ALTER TABLE public.version OWNER TO seqware;

--
-- Name: version_version_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE version_version_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.version_version_id_seq OWNER TO seqware;

--
-- Name: version_version_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE version_version_id_seq OWNED BY version.version_id;


--
-- Name: version_version_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('version_version_id_seq', 1, false);


--
-- Name: workflow; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE workflow (
    workflow_id integer NOT NULL,
    name text,
    description text,
    input_algorithm text,
    version text,
    seqware_version text,
    owner_id integer,
    base_ini_file text,
    cmd text,
    current_working_dir text,
    host text,
    username text,
    workflow_template text,
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    permanent_bundle_location text,
    workflow_class text,
    workflow_type text,
    workflow_engine text
);


ALTER TABLE public.workflow OWNER TO seqware;

--
-- Name: workflow_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE workflow_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.workflow_attribute_id_seq OWNER TO seqware;

--
-- Name: workflow_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('workflow_attribute_id_seq', 1, false);


--
-- Name: workflow_attribute; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE workflow_attribute (
    workflow_attribute_id integer DEFAULT nextval('workflow_attribute_id_seq'::regclass) NOT NULL,
    workflow_id integer NOT NULL,
    tag character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    unit character varying(255)
);


ALTER TABLE public.workflow_attribute OWNER TO seqware;

--
-- Name: workflow_param; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE workflow_param (
    workflow_param_id integer NOT NULL,
    workflow_id integer NOT NULL,
    type text NOT NULL,
    key text NOT NULL,
    display boolean,
    display_name text NOT NULL,
    file_meta_type text,
    default_value text
);


ALTER TABLE public.workflow_param OWNER TO seqware;

--
-- Name: workflow_param_value; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE workflow_param_value (
    workflow_param_value_id integer NOT NULL,
    workflow_param_id integer NOT NULL,
    display_name text NOT NULL,
    value text
);


ALTER TABLE public.workflow_param_value OWNER TO seqware;

--
-- Name: workflow_param_value_workflow_param_value_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE workflow_param_value_workflow_param_value_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.workflow_param_value_workflow_param_value_id_seq OWNER TO seqware;

--
-- Name: workflow_param_value_workflow_param_value_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE workflow_param_value_workflow_param_value_id_seq OWNED BY workflow_param_value.workflow_param_value_id;


--
-- Name: workflow_param_value_workflow_param_value_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('workflow_param_value_workflow_param_value_id_seq', 1, false);


--
-- Name: workflow_param_workflow_param_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE workflow_param_workflow_param_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.workflow_param_workflow_param_id_seq OWNER TO seqware;

--
-- Name: workflow_param_workflow_param_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE workflow_param_workflow_param_id_seq OWNED BY workflow_param.workflow_param_id;


--
-- Name: workflow_param_workflow_param_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('workflow_param_workflow_param_id_seq', 1, false);


--
-- Name: workflow_run; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE workflow_run (
    workflow_run_id integer NOT NULL,
    workflow_id integer NOT NULL,
    owner_id integer,
    name text,
    ini_file text,
    cmd text,
    workflow_template text,
    dax text,
    status text,
    status_cmd text,
    seqware_revision text,
    host text,
    current_working_dir text,
    username text,
    stderr text,
    stdout text,
    create_tstmp timestamp without time zone NOT NULL,
    update_tstmp timestamp without time zone,
    sw_accession integer DEFAULT nextval('sw_accession_seq'::regclass),
    workflow_engine text
);


ALTER TABLE public.workflow_run OWNER TO seqware;

--
-- Name: workflow_run_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE workflow_run_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.workflow_run_attribute_id_seq OWNER TO seqware;

--
-- Name: workflow_run_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('workflow_run_attribute_id_seq', 1, false);


--
-- Name: workflow_run_attribute; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE workflow_run_attribute (
    workflow_run_attribute_id integer DEFAULT nextval('workflow_run_attribute_id_seq'::regclass) NOT NULL,
    workflow_run_id integer NOT NULL,
    tag character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    unit character varying(255)
);


ALTER TABLE public.workflow_run_attribute OWNER TO seqware;

--
-- Name: workflow_run_param; Type: TABLE; Schema: public; Owner: seqware; Tablespace: 
--

CREATE TABLE workflow_run_param (
    workflow_run_param_id integer NOT NULL,
    workflow_run_id integer NOT NULL,
    type text,
    key text,
    parent_processing_accession integer,
    value text
);


ALTER TABLE public.workflow_run_param OWNER TO seqware;

--
-- Name: workflow_run_param_workflow_run_param_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE workflow_run_param_workflow_run_param_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.workflow_run_param_workflow_run_param_id_seq OWNER TO seqware;

--
-- Name: workflow_run_param_workflow_run_param_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE workflow_run_param_workflow_run_param_id_seq OWNED BY workflow_run_param.workflow_run_param_id;


--
-- Name: workflow_run_param_workflow_run_param_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('workflow_run_param_workflow_run_param_id_seq', 1, false);


--
-- Name: workflow_run_workflow_run_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE workflow_run_workflow_run_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.workflow_run_workflow_run_id_seq OWNER TO seqware;

--
-- Name: workflow_run_workflow_run_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE workflow_run_workflow_run_id_seq OWNED BY workflow_run.workflow_run_id;


--
-- Name: workflow_run_workflow_run_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('workflow_run_workflow_run_id_seq', 1, false);


--
-- Name: workflow_workflow_id_seq; Type: SEQUENCE; Schema: public; Owner: seqware
--

CREATE SEQUENCE workflow_workflow_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.workflow_workflow_id_seq OWNER TO seqware;

--
-- Name: workflow_workflow_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seqware
--

ALTER SEQUENCE workflow_workflow_id_seq OWNED BY workflow.workflow_id;


--
-- Name: workflow_workflow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seqware
--

SELECT pg_catalog.setval('workflow_workflow_id_seq', 48, true);


--
-- Name: experiment_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment ALTER COLUMN experiment_id SET DEFAULT nextval('experiment_experiment_id_seq'::regclass);


--
-- Name: experiment_attribute_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment_attribute ALTER COLUMN experiment_attribute_id SET DEFAULT nextval('experiment_attribute_experiment_attribute_id_seq'::regclass);


--
-- Name: experiment_library_design_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment_library_design ALTER COLUMN experiment_library_design_id SET DEFAULT nextval('experiment_library_design_experiment_library_design_id_seq'::regclass);


--
-- Name: experiment_link_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment_link ALTER COLUMN experiment_link_id SET DEFAULT nextval('experiment_link_experiment_link_id_seq'::regclass);


--
-- Name: experiment_spot_design_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment_spot_design ALTER COLUMN experiment_spot_design_id SET DEFAULT nextval('experiment_spot_design_experiment_spot_design_id_seq'::regclass);


--
-- Name: experiment_spot_design_read_spec_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment_spot_design_read_spec ALTER COLUMN experiment_spot_design_read_spec_id SET DEFAULT nextval('experiment_spot_design_read_s_experiment_spot_design_read_s_seq'::regclass);


--
-- Name: file_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY file ALTER COLUMN file_id SET DEFAULT nextval('file_file_id_seq'::regclass);


--
-- Name: row_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY file_report ALTER COLUMN row_id SET DEFAULT nextval('file_report_row_id_seq'::regclass);


--
-- Name: file_type_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY file_type ALTER COLUMN file_type_id SET DEFAULT nextval('file_type_file_type_id_seq'::regclass);


--
-- Name: ius_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY ius ALTER COLUMN ius_id SET DEFAULT nextval('ius_ius_id_seq'::regclass);


--
-- Name: ius_attribute_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY ius_attribute ALTER COLUMN ius_attribute_id SET DEFAULT nextval('ius_attribute_ius_attribute_id_seq'::regclass);


--
-- Name: ius_workflow_runs_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY ius_workflow_runs ALTER COLUMN ius_workflow_runs_id SET DEFAULT nextval('ius_workflow_runs_ius_workflow_runs_id_seq'::regclass);


--
-- Name: lane_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane ALTER COLUMN lane_id SET DEFAULT nextval('lane_lane_id_seq'::regclass);


--
-- Name: lane_attribute_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane_attribute ALTER COLUMN lane_attribute_id SET DEFAULT nextval('lane_attribute_lane_attribute_id_seq'::regclass);


--
-- Name: lane_type_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane_type ALTER COLUMN lane_type_id SET DEFAULT nextval('lane_type_lane_type_id_seq'::regclass);


--
-- Name: lane_workflow_runs_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane_workflow_runs ALTER COLUMN lane_workflow_runs_id SET DEFAULT nextval('lane_workflow_runs_lane_workflow_runs_id_seq'::regclass);


--
-- Name: library_selection_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY library_selection ALTER COLUMN library_selection_id SET DEFAULT nextval('library_selection_library_selection_id_seq'::regclass);


--
-- Name: library_source_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY library_source ALTER COLUMN library_source_id SET DEFAULT nextval('library_source_library_source_id_seq'::regclass);


--
-- Name: library_strategy_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY library_strategy ALTER COLUMN library_strategy_id SET DEFAULT nextval('library_strategy_library_strategy_id_seq'::regclass);


--
-- Name: organism_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY organism ALTER COLUMN organism_id SET DEFAULT nextval('organism_organism_id_seq'::regclass);


--
-- Name: platform_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY platform ALTER COLUMN platform_id SET DEFAULT nextval('platform_platform_id_seq'::regclass);


--
-- Name: processing_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing ALTER COLUMN processing_id SET DEFAULT nextval('processing_processing_id_seq'::regclass);


--
-- Name: processing_attribute_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_attribute ALTER COLUMN processing_attribute_id SET DEFAULT nextval('processing_attribute_processing_attribute_id_seq'::regclass);


--
-- Name: processing_experiments_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_experiments ALTER COLUMN processing_experiments_id SET DEFAULT nextval('processing_experiments_processing_experiments_id_seq'::regclass);


--
-- Name: processing_files_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_files ALTER COLUMN processing_files_id SET DEFAULT nextval('processing_files_processing_files_id_seq'::regclass);


--
-- Name: processing_ius_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_ius ALTER COLUMN processing_ius_id SET DEFAULT nextval('processing_ius_processing_ius_id_seq'::regclass);


--
-- Name: processing_lanes_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_lanes ALTER COLUMN processing_lanes_id SET DEFAULT nextval('processing_lanes_processing_lanes_id_seq'::regclass);


--
-- Name: processing_relationship_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_relationship ALTER COLUMN processing_relationship_id SET DEFAULT nextval('processing_relationship_processing_relationship_id_seq'::regclass);


--
-- Name: processing_samples_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_samples ALTER COLUMN processing_samples_id SET DEFAULT nextval('processing_samples_processing_samples_id_seq'::regclass);


--
-- Name: processing_sequencer_runs_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_sequencer_runs ALTER COLUMN processing_sequencer_runs_id SET DEFAULT nextval('processing_sequencer_runs_processing_sequencer_runs_id_seq'::regclass);


--
-- Name: processing_studies_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_studies ALTER COLUMN processing_studies_id SET DEFAULT nextval('processing_studies_processing_studies_id_seq'::regclass);


--
-- Name: registration_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY registration ALTER COLUMN registration_id SET DEFAULT nextval('registration_registration_id_seq'::regclass);


--
-- Name: sample_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample ALTER COLUMN sample_id SET DEFAULT nextval('sample_sample_id_seq'::regclass);


--
-- Name: sample_attribute_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample_attribute ALTER COLUMN sample_attribute_id SET DEFAULT nextval('sample_attribute_sample_attribute_id_seq'::regclass);


--
-- Name: sample_link_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample_link ALTER COLUMN sample_link_id SET DEFAULT nextval('sample_link_sample_link_id_seq'::regclass);


--
-- Name: sample_relationship_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample_relationship ALTER COLUMN sample_relationship_id SET DEFAULT nextval('sample_relationship_sample_relationship_id_seq'::regclass);


--
-- Name: row_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample_report ALTER COLUMN row_id SET DEFAULT nextval('sample_report_row_id_seq'::regclass);


--
-- Name: sequencer_run_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sequencer_run ALTER COLUMN sequencer_run_id SET DEFAULT nextval('sequencer_run_sequencer_run_id_seq'::regclass);


--
-- Name: sequencer_run_attribute_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sequencer_run_attribute ALTER COLUMN sequencer_run_attribute_id SET DEFAULT nextval('sequencer_run_attribute_sequencer_run_attribute_id_seq'::regclass);


--
-- Name: share_study_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_study ALTER COLUMN share_study_id SET DEFAULT nextval('share_study_id_seq'::regclass);


--
-- Name: share_workflow_run_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_workflow_run ALTER COLUMN share_workflow_run_id SET DEFAULT nextval('share_workflow_run_share_workflow_run_id_seq'::regclass);


--
-- Name: study_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY study ALTER COLUMN study_id SET DEFAULT nextval('study_study_id_seq'::regclass);


--
-- Name: study_attribute_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY study_attribute ALTER COLUMN study_attribute_id SET DEFAULT nextval('study_attribute_study_attribute_id_seq'::regclass);


--
-- Name: study_link_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY study_link ALTER COLUMN study_link_id SET DEFAULT nextval('study_link_study_link_id_seq'::regclass);


--
-- Name: study_type_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY study_type ALTER COLUMN study_type_id SET DEFAULT nextval('study_type_study_type_id_seq'::regclass);


--
-- Name: version_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY version ALTER COLUMN version_id SET DEFAULT nextval('version_version_id_seq'::regclass);


--
-- Name: workflow_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY workflow ALTER COLUMN workflow_id SET DEFAULT nextval('workflow_workflow_id_seq'::regclass);


--
-- Name: workflow_param_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY workflow_param ALTER COLUMN workflow_param_id SET DEFAULT nextval('workflow_param_workflow_param_id_seq'::regclass);


--
-- Name: workflow_param_value_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY workflow_param_value ALTER COLUMN workflow_param_value_id SET DEFAULT nextval('workflow_param_value_workflow_param_value_id_seq'::regclass);


--
-- Name: workflow_run_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY workflow_run ALTER COLUMN workflow_run_id SET DEFAULT nextval('workflow_run_workflow_run_id_seq'::regclass);


--
-- Name: workflow_run_param_id; Type: DEFAULT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY workflow_run_param ALTER COLUMN workflow_run_param_id SET DEFAULT nextval('workflow_run_param_workflow_run_param_id_seq'::regclass);


--
-- Data for Name: expense; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY expense (expense_id, invoice_id, workflow_run_id, agent, expense_type, description, price_per_unit, total_units, total_price, added_surcharge, sw_accession, expense_finished_tstmp) FROM stdin;
\.


--
-- Data for Name: expense_attribute; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY expense_attribute (expense_attribute_id, expense_id, tag, value, units) FROM stdin;
\.


--
-- Data for Name: experiment; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY experiment (experiment_id, study_id, experiment_library_design_id, experiment_spot_design_id, platform_id, name, title, description, alias, accession, status, center_name, sequence_space, base_caller, quality_scorer, quality_number_of_levels, quality_multiplier, quality_type, expected_number_runs, expected_number_spots, expected_number_reads, owner_id, sw_accession, create_tstmp, update_tstmp) FROM stdin;
1	1	\N	\N	20	PDE_ILLUMINA	PDE_ILLUMINA	PDE_ILLUMINA	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	3	2013-04-11 15:16:17.254	2013-04-11 15:16:17.255
\.


--
-- Data for Name: experiment_attribute; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY experiment_attribute (experiment_attribute_id, experiment_id, tag, value, units) FROM stdin;
\.


--
-- Data for Name: experiment_library_design; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY experiment_library_design (experiment_library_design_id, name, description, construction_protocol, strategy, source, selection, layout, paired_orientation, nominal_length, nominal_sdev) FROM stdin;
\.


--
-- Data for Name: experiment_link; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY experiment_link (experiment_link_id, experiment_id, label, url, db, id) FROM stdin;
\.


--
-- Data for Name: experiment_spot_design; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY experiment_spot_design (experiment_spot_design_id, decode_method, reads_per_spot, read_spec, tag_spec, adapter_spec) FROM stdin;
\.


--
-- Data for Name: experiment_spot_design_read_spec; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY experiment_spot_design_read_spec (experiment_spot_design_read_spec_id, experiment_spot_design_id, read_index, read_label, read_class, read_type, base_coord, cycle_coord, length, expected_basecall) FROM stdin;
\.


--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY file (file_id, file_path, md5sum, url, url_label, type, meta_type, description, owner_id, sw_accession, file_type_id, size) FROM stdin;
\.


--
-- Data for Name: file_attribute; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY file_attribute (file_attribute_id, file_id, tag, value, unit) FROM stdin;
\.


--
-- Data for Name: file_report; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY file_report (row_id, study_id, ius_id, lane_id, file_id, sample_id, experiment_id, child_sample_id, processing_id) FROM stdin;
\.


--
-- Data for Name: file_type; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY file_type (file_type_id, display_name, meta_type, extension) FROM stdin;
1	fastq file	chemical/seq-na-fastq	fastq
2	plain text file	text/plain	txt
3	bam file	application/bam	bam
4	gzip fastq file	chemical/seq-na-fastq-gzip	gz
\.


--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY invoice (invoice_id, owner_id, start_date, end_date, state, finalized, fully_paid, paid_amount, days_until_due, external_id, client_notes, notes, sw_accession, create_tstmp) FROM stdin;
\.


--
-- Data for Name: invoice_attribute; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY invoice_attribute (invoice_attribute_id, invoice_id, tag, value, units) FROM stdin;
\.


--
-- Data for Name: ius; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY ius (ius_id, sample_id, lane_id, owner_id, name, alias, description, tag, sw_accession, create_tstmp, update_tstmp, skip) FROM stdin;
1	3	1	1	NoIndex	\N	NoIndex	NoIndex	8	2013-04-11 15:16:18.247	2013-04-11 15:16:18.248	f
2	4	2	1	NoIndex	\N	NoIndex	NoIndex	11	2013-04-11 15:16:18.952	2013-04-11 15:16:18.952	f
3	5	3	1	NoIndex	\N	NoIndex	NoIndex	14	2013-04-11 15:16:19.634	2013-04-11 15:16:19.635	f
4	7	4	1	NoIndex	\N	NoIndex	NoIndex	18	2013-04-11 15:16:20.407	2013-04-11 15:16:20.407	f
5	8	5	1	NoIndex	\N	NoIndex	NoIndex	21	2013-04-11 15:16:21.088	2013-04-11 15:16:21.089	f
6	9	6	1	NoIndex	\N	NoIndex	NoIndex	24	2013-04-11 15:16:21.716	2013-04-11 15:16:21.719	f
7	10	7	1	NoIndex	\N	NoIndex	NoIndex	27	2013-04-11 15:16:22.392	2013-04-11 15:16:22.392	f
8	11	8	1	NoIndex	\N	NoIndex	NoIndex	30	2013-04-11 15:16:23.064	2013-04-11 15:16:23.065	f
10	17	10	1	TTAGGC	\N	TTAGGC	TTAGGC	41	2013-04-11 15:37:46	2013-04-11 15:37:46	f
11	20	10	1	ATCACG	\N	ATCACG	ATCACG	45	2013-04-11 15:37:46.628	2013-04-11 15:37:46.629	f
13	25	10	1	ACAGTG	\N	ACAGTG	ACAGTG	52	2013-04-11 15:37:47.747	2013-04-11 15:37:47.748	f
14	27	11	1	NoIndex	\N	NoIndex	NoIndex	56	2013-04-11 15:37:48.479	2013-04-11 15:37:48.483	f
15	28	12	1	NoIndex	\N	NoIndex	NoIndex	59	2013-04-11 15:37:49.155	2013-04-11 15:37:49.155	f
16	29	13	1	NoIndex	\N	NoIndex	NoIndex	62	2013-04-11 15:37:49.8	2013-04-11 15:37:49.801	f
17	31	14	1	NoIndex	\N	NoIndex	NoIndex	66	2013-04-11 15:37:50.524	2013-04-11 15:37:50.524	f
20	35	16	1	NoIndex	\N	NoIndex	NoIndex	75	2013-04-11 15:37:52.359	2013-04-11 15:37:52.359	f
12	23	10	1	CGATGT	\N	CGATGT	CGATGT	49	2013-04-11 15:37:47.247	2013-04-11 16:08:04.243	t
9	14	9	1	NoIndex	\N	NoIndex	NoIndex	36	2013-04-11 15:37:45.187	2013-04-11 16:09:33.269	t
22	37	18	1	NoIndex	\N	NoIndex	NoIndex	82	2013-04-11 15:40:02.186	2013-04-11 16:21:33.103	t
21	36	17	1	NoIndex	\N	NoIndex	NoIndex	79	2013-04-11 15:40:01.47	2013-04-11 16:21:33.103	t
18	32	15	1	TGACCA	\N	TGACCA	TGACCA	69	2013-04-11 15:37:51.2	2013-04-11 15:37:51.2	t
19	33	15	1	ACAGTG	\N	ACAGTG	ACAGTG	71	2013-04-11 15:37:51.651	2013-04-11 15:37:51.652	t
\.


--
-- Data for Name: ius_attribute; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY ius_attribute (ius_attribute_id, ius_id, tag, value, units) FROM stdin;
1	12	skip	ius skip	\N
2	9	skip	ius skip	\N
\.


--
-- Data for Name: ius_link; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY ius_link (ius_link_id, ius_id, label, url, db, id) FROM stdin;
\.


--
-- Data for Name: ius_workflow_runs; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY ius_workflow_runs (ius_workflow_runs_id, ius_id, workflow_run_id) FROM stdin;
\.


--
-- Data for Name: lane; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY lane (lane_id, sequencer_run_id, sample_id, organism_id, name, alias, description, lane_index, cycle_descriptor, cycle_count, cycle_sequence, type, study_type, library_strategy, library_selection, library_source, skip, tags, regions, sw_accession, owner_id, create_tstmp, update_tstmp) FROM stdin;
1	1	\N	\N	8	\N	8	7		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	4	1	2013-04-11 15:16:17.42	2013-04-11 15:16:17.533
2	1	\N	\N	3	\N	3	2		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	9	1	2013-04-11 15:16:18.407	2013-04-11 15:16:18.516
3	1	\N	\N	4	\N	4	3		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	12	1	2013-04-11 15:16:19.065	2013-04-11 15:16:19.149
4	1	\N	\N	7	\N	7	6		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	15	1	2013-04-11 15:16:19.77	2013-04-11 15:16:19.875
5	1	\N	\N	5	\N	5	4		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	19	1	2013-04-11 15:16:20.539	2013-04-11 15:16:20.629
6	1	\N	\N	2	\N	2	1		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	22	1	2013-04-11 15:16:21.218	2013-04-11 15:16:21.325
7	1	\N	\N	1	\N	1	0		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	25	1	2013-04-11 15:16:21.841	2013-04-11 15:16:21.966
8	1	\N	\N	6	\N	6	5		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	28	1	2013-04-11 15:16:22.518	2013-04-11 15:16:22.62
9	2	\N	\N	7	\N	7	6		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	32	1	2013-04-11 15:37:44.427	2013-04-11 15:37:44.534
10	2	\N	\N	3	\N	3	2		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	37	1	2013-04-11 15:37:45.3	2013-04-11 15:37:45.396
11	2	\N	\N	5	\N	5	4		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	53	1	2013-04-11 15:37:47.861	2013-04-11 15:37:47.953
12	2	\N	\N	2	\N	2	1		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	57	1	2013-04-11 15:37:48.603	2013-04-11 15:37:48.692
13	2	\N	\N	1	\N	1	0		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	60	1	2013-04-11 15:37:49.281	2013-04-11 15:37:49.386
14	2	\N	\N	6	\N	6	5		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	63	1	2013-04-11 15:37:49.929	2013-04-11 15:37:50.03
16	2	\N	\N	8	\N	8	7		\N	\N	\N	\N	\N	\N	\N	f	\N	\N	72	1	2013-04-11 15:37:51.775	2013-04-11 15:37:51.877
17	3	\N	\N	1	\N	1	0		\N	\N	\N	\N	\N	\N	\N	t	\N	\N	77	1	2013-04-11 15:40:00.916	2013-04-11 16:21:33.102
18	3	\N	\N	2	\N	2	1		\N	\N	\N	\N	\N	\N	\N	t	\N	\N	80	1	2013-04-11 15:40:01.583	2013-04-11 16:21:33.102
15	2	\N	\N	4	\N	4	3		\N	\N	\N	\N	\N	\N	\N	t	\N	\N	67	1	2013-04-11 15:37:50.646	2013-04-11 15:37:50.741
\.


--
-- Data for Name: lane_attribute; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY lane_attribute (lane_attribute_id, lane_id, tag, value, units) FROM stdin;
1	1	geo_lane	8	\N
2	2	geo_lane	3	\N
3	3	geo_lane	4	\N
4	4	geo_lane	7	\N
5	5	geo_lane	5	\N
6	6	geo_lane	2	\N
7	7	geo_lane	1	\N
8	8	geo_lane	6	\N
9	9	geo_lane	7	\N
10	10	geo_lane	3	\N
11	11	geo_lane	5	\N
12	12	geo_lane	2	\N
13	13	geo_lane	1	\N
14	14	geo_lane	6	\N
15	15	geo_lane	4	\N
16	16	geo_lane	8	\N
17	17	geo_lane	1	\N
18	18	geo_lane	2	\N
21	15	skip	lane_skip	\N
\.


--
-- Data for Name: lane_link; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY lane_link (lane_link_id, lane_id, label, url, db, id) FROM stdin;
\.


--
-- Data for Name: lane_type; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY lane_type (lane_type_id, code, name) FROM stdin;
1	genomic_sequencing	Genomic Sequencing
2	cdna_sequencing	CDNA Sequencing
3	chipseq	Chip Sequencing
4	digital_gene_expression_dpnII	Digital Gene Expression: DPNII
5	digital_gene_expression_nlaIII	Digital Gene Expression: NLAIII
6	bisulfite_sequencing	Bi-sulfite Sequencing
7	other (add to description)	other (add to description)
\.


--
-- Data for Name: lane_workflow_runs; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY lane_workflow_runs (lane_workflow_runs_id, lane_id, workflow_run_id) FROM stdin;
\.


--
-- Data for Name: library_selection; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY library_selection (library_selection_id, name, description) FROM stdin;
2	PCR	Source material was selected by designed primers
3	RANDOM PCR	Source material was selected by randomly generated primers
4	RT-PCR	Source material was selected by reverse transcription PCR
5	HMPR	Hypo-methylated partial restriction digest
6	MF	Methyl Filtrated
7	CF-S	Cot-filtered single/low-copy genomic DNA
8	CF-M	Cot-filtered moderately repetitive genomic DNA
9	CF-H	Cot-filtered highly repetitive genomic DNA
10	CF-T	Cot-filtered theoretical single-copy genomic DNA
11	MSLL	Methylation Spanning Linking Library
12	cDNA	complementary DNA
13	ChIP	Chromatin immunoprecipitation
14	MNase	Micrococcal Nuclease (MNase) digestion
1	RANDOM	Random selection by shearing or other method
17	DNAse	Deoxyribonuclease (MNase) digestion
18	Hybrid Selection	Selection by hybridization in array or solution
19	Reduced Representation	Reproducible genomic subsets, often generated by restriction fragment size selection, containing a manageable number of loci to facilitate re-sampling
20	Restriction Digest	DNA fractionation using restriction enzymes
21	5-methylcytidine antibody	Selection of methylated DNA fragments using an antibody raised against 5-methylcytosine or 5-methylcytidine (m5C)
22	MBD2 protein methyl-CpG binding domain	Enrichment by methyl-CpG binding domain
23	CAGE	Cap-analysis gene expression
24	RACE	Rapid Amplification of cDNA Ends
25	size fractionation	Physical selection of size appropriate targets
15	other	Other library enrichment, screening, or selection process
16	unspecified	Library enrichment, screening, or selection is not specified
\.


--
-- Data for Name: library_source; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY library_source (library_source_id, name, description) FROM stdin;
1	GENOMIC	Genomic DNA (includes PCR products from genomic DNA)
6	TRANSCRIPTOMIC	Transcription products or non genomic DNA (EST, cDNA, RT-PCR, screened libraries)
7	METAGENOMIC	Mixed material from metagenome
2	NON GENOMIC	Deprecated - Use TRANSCRIPTOMIC or METAGENOMIC
3	SYNTHETIC	Synthetic DNA
4	VIRAL RNA	Viral RNA
5	OTHER	Other, unspecified, or unknown library source material
\.


--
-- Data for Name: library_strategy; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY library_strategy (library_strategy_id, name, description) FROM stdin;
3	CLONE	Genomic clone based (hierarchical) sequencing
4	POOLCLONE	Shotgun of pooled clones (usually BACs and Fosmids)
5	AMPLICON	Sequencing of overlapping or distinct PCR or RT-PCR products
6	BARCODE	Sequencing of overlapping or distinct  products that have been tagged with a short identifying sequence (barcode).  Each sequence read can therefore be assigned to an individual product
7	CLONEEND	Clone end (5', 3', or both) sequencing
8	FINISHING	Sequencing intended to finish (close) gaps in existing coverage
9	ChIP-Seq	Direct sequencing of chromatin immunoprecipitates
10	MNase-Seq	Direct sequencing following MNase digestion
11	EST	Single pass sequencing of cDNA templates
12	FL-cDNA	Full-length sequencing of cDNA templates
13	CTS	Concatenated Tag Sequencing
14	OTHER	Library strategy not listed
15	RNA-Seq	Random sequencing of whole transcriptome.
1	WGS	Random sequencing of the whole genome
2	WCS	Random sequencing of a whole chromosome or other replicon isolated from a genome
16	WXS	Random sequencing of exonic regions selected from the genome
17	DNase-Hypersensitivity	Sequencing of hypersensitive sites, or segments of open chromatin that are more readily cleaved by DNaseI
18	Bisulfite-Seq	Sequencing following treatment of DNA with bisulfite to convert cytosine residues to uracil depending on methylation status
19	MRE-Seq	Methylation-Sensitive Restriction Enzyme Sequencing strategy
20	MeDIP-Seq	Methylated DNA Immunoprecipitation Sequencing strategy
21	MBD-Seq	Direct sequencing of methylated fractions sequencing strategy
\.


--
-- Data for Name: organism; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY organism (organism_id, code, name, accession, ncbi_taxid) FROM stdin;
1	Anolis_carolinensis	Anolis carolinensis	\N	\N
2	Anopheles_gambiae	Anopheles gambiae	\N	\N
3	Apis_mellifera	Apis mellifera	\N	\N
4	Bos_taurus	Bos taurus	\N	\N
5	Branchiostoma_floridae	Branchiostoma floridae	\N	\N
6	Caenorhabditis_brenneri	Caenorhabditis brenneri	\N	\N
7	Caenorhabditis_briggsae	Caenorhabditis briggsae	\N	\N
9	Caenorhabditis_japonica	Caenorhabditis japonica	\N	\N
10	Caenorhabditis_remanei	Caenorhabditis remanei	\N	\N
11	Callithrix_jacchus	Callithrix jacchus	\N	\N
12	Canis_familiaris	Canis familiaris	\N	\N
13	Cavia_porcellus	Cavia porcellus	\N	\N
14	Ciona_intestinalis	Ciona intestinalis	\N	\N
15	Danio_rerio	Danio rerio	\N	\N
16	Drosophila_ananassae	Drosophila ananassae	\N	\N
17	Drosophila_erecta	Drosophila erecta	\N	\N
18	Drosophila_grimshawi	Drosophila grimshawi	\N	\N
19	Drosophila_melanogaster	Drosophila melanogaster	\N	\N
20	Drosophila_mojavensis	Drosophila mojavensis	\N	\N
21	Drosophila_persimilis	Drosophila persimilis	\N	\N
22	Drosophila_pseudoobscura	Drosophila pseudoobscura	\N	\N
23	Drosophila_sechellia	Drosophila sechellia	\N	\N
24	Drosophila_simulans	Drosophila simulans	\N	\N
25	Drosophila_virilis	Drosophila virilis	\N	\N
26	Drosophila_yakuba	Drosophila yakuba	\N	\N
27	Equus_caballus	Equus caballus	\N	\N
28	Felis_catus	Felis catus	\N	\N
29	Fugu_rubripes	Fugu rubripes	\N	\N
30	Gallus_gallus	Gallus gallus	\N	\N
32	Monodelphis_domestica	Monodelphis domestica	\N	\N
34	Ornithorhynchus_anatinus	Ornithorhynchus anatinus	\N	\N
35	Oryzias_latipes	Oryzias latipes	\N	\N
36	Pan_troglodytes	Pan troglodytes	\N	\N
37	Petromyzon_marinus	Petromyzon marinus	\N	\N
39	Rhesus_macaque	Rhesus macaque	\N	\N
40	SARS_coronavirus	SARS coronavirus	\N	\N
41	Saccharomyces_cereviciae	Saccharomyces cereviciae	\N	\N
42	Saccharomyces_cerevisiae	Saccharomyces cerevisiae	\N	\N
43	Strongylocentrotus_purpuratus	Strongylocentrotus purpuratus	\N	\N
44	Takifugu_rubripes	Takifugu rubripes	\N	\N
45	Tetraodon_nigroviridis	Tetraodon nigroviridis	\N	\N
46	Xenopus_tropicalis	Xenopus tropicalis	\N	\N
48	Escherichia_coli_str._K-12_substr._DH10B	Escherichia coli str. K-12 substr. DH10B	\N	316385
49	Enterobacteria_phage_phiX174	Enterobacteria phage phiX174	\N	10847
50	Chlorocebus_pygerythrus	Chlorocebus pygerythrus	\N	60710
51	Plasmodium_falciparum	Plasmodium falciparum	\N	5833
52	Rhodobacter_sphaeroides	Rhodobacter sphaeroides	\N	1063
53	Staphylococcus_aureus	Staphylococcus aureus	\N	1280
54	OICR_Vaccinia_jx-594	OICR Vaccinia JX-594	\N	\N
55	OICR_De_novo_assembly	OICR De novo assembly	\N	\N
56	OICR_See_comments	OICR See Comments	\N	\N
47	Other	Other (add to description)	\N	\N
31	Homo_sapiens	Homo sapiens	\N	9606
33	Mus_musculus	Mus musculus	\N	10090
38	Rattus_norvegicus	Rattus norvegicus	\N	10116
8	Caenorhabditis_elegans	Caenorhabditis elegans	\N	6239
\.


--
-- Data for Name: platform; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY platform (platform_id, name, instrument_model, description) FROM stdin;
1	LS454	GS 20	454 technology use 1-color sequential flows
2	LS454	GS FLX	454 technology use 1-color sequential flows
3	LS454	454 GS	454 technology use 1-color sequential flows
4	LS454	454 GS 20	454 technology use 1-color sequential flows
5	LS454	454 GS FLX	454 technology use 1-color sequential flows
6	LS454	unspecified	454 technology use 1-color sequential flows
7	ILLUMINA	Solexa 1G Genome Analyzer	Illumina is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
8	ILLUMINA	Illumina Genome Analyzer	Illumina is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
9	ILLUMINA	Illumina Genome Analyzer II	Illumina is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
10	ILLUMINA	unspecified	Illumina is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
11	HELICOS	Helicos HeliScope	Helicos is similar to 454 technology - uses 1-color sequential flows
12	HELICOS	unspecified	Helicos is similar to 454 technology - uses 1-color sequential flows
13	ABI_SOLID	AB SOLiD System	ABI is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
14	ABI_SOLID	AB SOLiD System 2.0	ABI is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
15	ABI_SOLID	AB SOLiD System 3.0	ABI is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
16	ABI_SOLID	AB SOLiD System 3 Plus	ABI is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
17	ABI_SOLID	AB SOLiD System 4	ABI is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
18	ABI_SOLID	AB SOLiD System PI	ABI is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
19	ABI_SOLID	unspecified	ABI is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
20	ILLUMINA	Illumina HiSeq 2000	Illumina is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
21	ILLUMINA	Illumina HiSeq 1000	Illumina is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
22	ILLUMINA	Illumina HiScan SQ	Illumina is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
23	ILLUMINA	Illumina Genome Analyzer IIx	Illumina is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
24	ABI_SOLID	AB SOLiD 5500xl	ABI is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
25	ABI_SOLID	AB SOLiD 5500	ABI is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
26	ILLUMINA	Illumina MiSeq	Illumina is 4-channel flowgram with 1-to-1 mapping between basecalls and flows
27	ION_TORRENT	Ion Torrent PGM	Ion Torrent Personal Genome Machine (PGM) from Life Technologies.
28	PACBIO_SMRT	PacBio RS	PacificBiosciences platform type for the single molecule real time (SMRT) technology.
\.


--
-- Data for Name: processing; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY processing (processing_id, workflow_run_id, ancestor_workflow_run_id, algorithm, status, description, url, url_label, version, parameters, stdout, stderr, exit_status, process_exit_status, task_group, owner_id, sw_accession, run_start_tstmp, run_stop_tstmp, create_tstmp, update_tstmp) FROM stdin;
\.


--
-- Data for Name: processing_attribute; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY processing_attribute (processing_attribute_id, processing_id, tag, value, units) FROM stdin;
\.


--
-- Data for Name: processing_experiments; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY processing_experiments (processing_experiments_id, experiment_id, processing_id, description, label, url, sw_accession) FROM stdin;
\.


--
-- Data for Name: processing_files; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY processing_files (processing_files_id, processing_id, file_id) FROM stdin;
\.


--
-- Data for Name: processing_ius; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY processing_ius (processing_ius_id, ius_id, processing_id, description, label, url, sw_accession) FROM stdin;
\.


--
-- Data for Name: processing_lanes; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY processing_lanes (processing_lanes_id, lane_id, processing_id, description, label, url, sw_accession) FROM stdin;
\.


--
-- Data for Name: processing_relationship; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY processing_relationship (processing_relationship_id, parent_id, child_id, relationship) FROM stdin;
\.


--
-- Data for Name: processing_samples; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY processing_samples (processing_samples_id, sample_id, processing_id, description, label, url, sw_accession) FROM stdin;
\.


--
-- Data for Name: processing_sequencer_runs; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY processing_sequencer_runs (processing_sequencer_runs_id, sequencer_run_id, processing_id, description, label, url, sw_accession) FROM stdin;
\.


--
-- Data for Name: processing_studies; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY processing_studies (processing_studies_id, study_id, processing_id, description, label, url, sw_accession) FROM stdin;
\.


--
-- Data for Name: registration; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY registration (registration_id, email, password, password_hint, first_name, last_name, institution, invitation_code, lims_admin, create_tstmp, last_update_tstmp, developer_ml, user_ml, payee) FROM stdin;
1	admin@admin.com	admin	admin	LIMS	Admin	Institution	\N	t	2009-09-15 19:33:40.428035	2009-09-15 19:33:40.428035	f	f	f
\.


--
-- Data for Name: sample; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY sample (sample_id, experiment_id, organism_id, name, title, alias, type, scientific_name, common_name, anonymized_name, individual_name, description, taxon_id, tags, adapters, regions, expected_number_runs, expected_number_spots, expected_number_reads, skip, is_public, owner_id, sw_accession, create_tstmp, update_tstmp) FROM stdin;
1	1	31	TEST_0001	TEST_0001	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	5	2013-04-11 15:16:17.674	2013-04-11 15:16:17.675
2	\N	31	TEST_0001_Pa_P	TEST_0001_Pa_P	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	6	2013-04-11 15:16:17.805	2013-04-11 15:16:17.805
3	\N	31	TEST_0001_Pa_P_PE_350_EX	TEST_0001_Pa_P_PE_350_EX	\N	\N	\N	\N	\N	\N	TEST_0001_Pa_P_PE_350_EX	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	7	2013-04-11 15:16:17.922	2013-04-11 15:16:18.085
4	\N	31	TEST_0001_Pa_P_PE_400_WG	TEST_0001_Pa_P_PE_400_WG	\N	\N	\N	\N	\N	\N	TEST_0001_Pa_P_PE_400_WG	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	10	2013-04-11 15:16:18.648	2013-04-11 15:16:18.807
5	\N	31	TEST_0001_Pa_P_PE_300_WG	TEST_0001_Pa_P_PE_300_WG	\N	\N	\N	\N	\N	\N	TEST_0001_Pa_P_PE_300_WG	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	13	2013-04-11 15:16:19.29	2013-04-11 15:16:19.469
6	\N	31	TEST_0001_Ly_R	TEST_0001_Ly_R	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	16	2013-04-11 15:16:20.002	2013-04-11 15:16:20.003
7	\N	31	TEST_0001_Ly_R_PE_250_EX	TEST_0001_Ly_R_PE_250_EX	\N	\N	\N	\N	\N	\N	TEST_0001_Ly_R_PE_250_EX	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	17	2013-04-11 15:16:20.105	2013-04-11 15:16:20.25
8	\N	31	TEST_0001_Pa_P_PE_396_MR	TEST_0001_Pa_P_PE_396_MR	\N	\N	\N	\N	\N	\N	TEST_0001_Pa_P_PE_396_MR	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	20	2013-04-11 15:16:20.756	2013-04-11 15:16:20.923
9	\N	31	TEST_0001_Ly_R_PE_600_WG	TEST_0001_Ly_R_PE_600_WG	\N	\N	\N	\N	\N	\N	TEST_0001_Ly_R_PE_600_WG	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	23	2013-04-11 15:16:21.445	2013-04-11 15:16:21.575
10	\N	31	TEST_0001_Ly_R_PE_500_WG	TEST_0001_Ly_R_PE_500_WG	\N	\N	\N	\N	\N	\N	TEST_0001_Ly_R_PE_500_WG	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	26	2013-04-11 15:16:22.113	2013-04-11 15:16:22.247
11	\N	31	TEST_0001_Pa_P_PE_296_WT	TEST_0001_Pa_P_PE_296_WT	\N	\N	\N	\N	\N	\N	TEST_0001_Pa_P_PE_296_WT	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	29	2013-04-11 15:16:22.786	2013-04-11 15:16:22.91
12	1	31	TEST_0002	TEST_0002	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	33	2013-04-11 15:37:44.656	2013-04-11 15:37:44.657
13	\N	31	TEST_0002_Ly_R	TEST_0002_Ly_R	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	34	2013-04-11 15:37:44.776	2013-04-11 15:37:44.776
14	\N	31	TEST_0002_Ly_R_PE_500_EX	TEST_0002_Ly_R_PE_500_EX	\N	\N	\N	\N	\N	\N	TEST_0002_Ly_R_PE_500_EX	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	35	2013-04-11 15:37:44.884	2013-04-11 15:37:45.034
15	1	31	TEST_0003	TEST_0003	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	38	2013-04-11 15:37:45.518	2013-04-11 15:37:45.518
16	\N	31	TEST_0003_Pa_X	TEST_0003_Pa_X	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	39	2013-04-11 15:37:45.639	2013-04-11 15:37:45.639
17	\N	31	TEST_0003_Pa_X_PE_401_EX	TEST_0003_Pa_X_PE_401_EX	\N	\N	\N	\N	\N	\N	TEST_0003_Pa_X_PE_401_EX	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	40	2013-04-11 15:37:45.733	2013-04-11 15:37:45.856
18	1	31	TEST_0005	TEST_0005	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	42	2013-04-11 15:37:46.115	2013-04-11 15:37:46.115
19	\N	31	TEST_0005_Pa_X	TEST_0005_Pa_X	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	43	2013-04-11 15:37:46.235	2013-04-11 15:37:46.236
20	\N	31	TEST_0005_Pa_X_PE_150_WG	TEST_0005_Pa_X_PE_150_WG	\N	\N	\N	\N	\N	\N	TEST_0005_Pa_X_PE_150_WG	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	44	2013-04-11 15:37:46.347	2013-04-11 15:37:46.47
21	1	31	TEST_0004	TEST_0004	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	46	2013-04-11 15:37:46.754	2013-04-11 15:37:46.755
22	\N	31	TEST_0004_Pa_C	TEST_0004_Pa_C	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	47	2013-04-11 15:37:46.872	2013-04-11 15:37:46.872
23	\N	31	TEST_0004_Pa_C_PE_501_EX	TEST_0004_Pa_C_PE_501_EX	\N	\N	\N	\N	\N	\N	TEST_0004_Pa_C_PE_501_EX	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	48	2013-04-11 15:37:46.967	2013-04-11 15:37:47.108
24	\N	31	TEST_0002_Pa_P	TEST_0002_Pa_P	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	50	2013-04-11 15:37:47.376	2013-04-11 15:37:47.377
25	\N	31	TEST_0002_Pa_P_PE_400_EX	TEST_0002_Pa_P_PE_400_EX	\N	\N	\N	\N	\N	\N	TEST_0002_Pa_P_PE_400_EX	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	51	2013-04-11 15:37:47.479	2013-04-11 15:37:47.611
26	\N	31	TEST_0001_Pa_X	TEST_0001_Pa_X	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	54	2013-04-11 15:37:48.075	2013-04-11 15:37:48.075
27	\N	31	TEST_0001_Pa_X_PE_200_WG	TEST_0001_Pa_X_PE_200_WG	\N	\N	\N	\N	\N	\N	TEST_0001_Pa_X_PE_200_WG	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	55	2013-04-11 15:37:48.159	2013-04-11 15:37:48.293
28	\N	31	TEST_0001_Pa_P_PE_300_WG	TEST_0001_Pa_P_PE_300_WG	\N	\N	\N	\N	\N	\N	TEST_0001_Pa_P_PE_300_WG	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	58	2013-04-11 15:37:48.852	2013-04-11 15:37:48.997
29	\N	31	TEST_0001_Ly_R_PE_500_WG	TEST_0001_Ly_R_PE_500_WG	\N	\N	\N	\N	\N	\N	TEST_0001_Ly_R_PE_500_WG	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	61	2013-04-11 15:37:49.528	2013-04-11 15:37:49.655
30	\N	31	TEST_0001_Pa_C	TEST_0001_Pa_C	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	64	2013-04-11 15:37:50.164	2013-04-11 15:37:50.164
31	\N	31	TEST_0001_Pa_C_PE_700_WG	TEST_0001_Pa_C_PE_700_WG	\N	\N	\N	\N	\N	\N	TEST_0001_Pa_C_PE_700_WG	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	65	2013-04-11 15:37:50.255	2013-04-11 15:37:50.384
32	\N	31	TEST_0002_Pa_P_PE_400_EX	TEST_0002_Pa_P_PE_400_EX	\N	\N	\N	\N	\N	\N	TEST_0002_Pa_P_PE_400_EX	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	68	2013-04-11 15:37:50.87	2013-04-11 15:37:50.998
33	\N	31	TEST_0003_Pa_X_PE_401_EX	TEST_0003_Pa_X_PE_401_EX	\N	\N	\N	\N	\N	\N	TEST_0003_Pa_X_PE_401_EX	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	70	2013-04-11 15:37:51.367	2013-04-11 15:37:51.505
34	\N	31	TEST_0003_Ly_R	TEST_0003_Ly_R	\N	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	\N	\N	\N	\N	1	73	2013-04-11 15:37:52.013	2013-04-11 15:37:52.013
35	\N	31	TEST_0003_Ly_R_PE_402_EX	TEST_0003_Ly_R_PE_402_EX	\N	\N	\N	\N	\N	\N	TEST_0003_Ly_R_PE_402_EX	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	74	2013-04-11 15:37:52.099	2013-04-11 15:37:52.221
36	\N	31	TEST_0001_Ly_R_PE_500_WG	TEST_0001_Ly_R_PE_500_WG	\N	\N	\N	\N	\N	\N	TEST_0001_Ly_R_PE_500_WG	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	78	2013-04-11 15:40:01.191	2013-04-11 15:40:01.321
37	\N	31	TEST_0001_Pa_P_PE_400_WG	TEST_0001_Pa_P_PE_400_WG	\N	\N	\N	\N	\N	\N	TEST_0001_Pa_P_PE_400_WG	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	81	2013-04-11 15:40:01.823	2013-04-11 15:40:01.957
\.


--
-- Data for Name: sample_attribute; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY sample_attribute (sample_attribute_id, sample_id, tag, value, units) FROM stdin;
1	3	geo_tissue_type	P	\N
2	3	geo_library_source_template_type	EX	\N
3	3	geo_library_type	PE	\N
4	3	geo_tissue_origin	Pa	\N
5	3	geo_library_size_code	350	\N
6	4	geo_tissue_type	P	\N
7	4	geo_library_source_template_type	WG	\N
8	4	geo_library_type	PE	\N
9	4	geo_tissue_origin	Pa	\N
10	4	geo_library_size_code	400	\N
11	5	geo_tissue_type	P	\N
12	5	geo_library_source_template_type	WG	\N
13	5	geo_library_type	PE	\N
14	5	geo_tissue_origin	Pa	\N
15	5	geo_library_size_code	300	\N
16	7	geo_tissue_type	R	\N
17	7	geo_library_source_template_type	EX	\N
18	7	geo_library_type	PE	\N
19	7	geo_tissue_origin	Ly	\N
20	7	geo_library_size_code	250	\N
21	8	geo_tissue_type	P	\N
22	8	geo_library_source_template_type	MR	\N
23	8	geo_library_type	PE	\N
24	8	geo_tissue_origin	Pa	\N
25	8	geo_library_size_code	396	\N
26	9	geo_tissue_type	R	\N
27	9	geo_library_source_template_type	WG	\N
28	9	geo_library_type	PE	\N
29	9	geo_tissue_origin	Ly	\N
30	9	geo_library_size_code	600	\N
31	10	geo_tissue_type	R	\N
32	10	geo_library_source_template_type	WG	\N
33	10	geo_library_type	PE	\N
34	10	geo_tissue_origin	Ly	\N
35	10	geo_library_size_code	500	\N
36	11	geo_tissue_type	P	\N
37	11	geo_library_source_template_type	WT	\N
38	11	geo_library_type	PE	\N
39	11	geo_tissue_origin	Pa	\N
40	11	geo_library_size_code	296	\N
41	14	geo_tissue_type	R	\N
42	14	geo_library_source_template_type	EX	\N
43	14	geo_library_type	PE	\N
44	14	geo_tissue_origin	Ly	\N
45	14	geo_library_size_code	500	\N
46	17	geo_tissue_type	X	\N
47	17	geo_library_source_template_type	EX	\N
48	17	geo_library_type	PE	\N
49	17	geo_tissue_origin	Pa	\N
50	17	geo_library_size_code	401	\N
51	20	geo_tissue_type	X	\N
52	20	geo_library_source_template_type	WG	\N
53	20	geo_library_type	PE	\N
54	20	geo_tissue_origin	Pa	\N
55	20	geo_library_size_code	150	\N
56	23	geo_tissue_type	C	\N
57	23	geo_library_source_template_type	EX	\N
58	23	geo_library_type	PE	\N
59	23	geo_tissue_origin	Pa	\N
60	23	geo_library_size_code	501	\N
61	25	geo_tissue_type	P	\N
62	25	geo_library_source_template_type	EX	\N
63	25	geo_library_type	PE	\N
64	25	geo_tissue_origin	Pa	\N
65	25	geo_library_size_code	400	\N
66	27	geo_tissue_type	X	\N
67	27	geo_library_source_template_type	WG	\N
68	27	geo_library_type	PE	\N
69	27	geo_tissue_origin	Pa	\N
70	27	geo_library_size_code	200	\N
71	28	geo_tissue_type	P	\N
72	28	geo_library_source_template_type	WG	\N
73	28	geo_library_type	PE	\N
74	28	geo_tissue_origin	Pa	\N
75	28	geo_library_size_code	300	\N
76	29	geo_tissue_type	R	\N
77	29	geo_library_source_template_type	WG	\N
78	29	geo_library_type	PE	\N
79	29	geo_tissue_origin	Ly	\N
80	29	geo_library_size_code	500	\N
81	31	geo_tissue_type	C	\N
82	31	geo_library_source_template_type	WG	\N
83	31	geo_library_type	PE	\N
84	31	geo_tissue_origin	Pa	\N
85	31	geo_library_size_code	700	\N
86	32	geo_tissue_type	P	\N
87	32	geo_library_source_template_type	EX	\N
88	32	geo_library_type	PE	\N
89	32	geo_tissue_origin	Pa	\N
90	32	geo_library_size_code	400	\N
91	33	geo_tissue_type	X	\N
92	33	geo_library_source_template_type	EX	\N
93	33	geo_library_type	PE	\N
94	33	geo_tissue_origin	Pa	\N
95	33	geo_library_size_code	401	\N
96	35	geo_tissue_type	R	\N
97	35	geo_library_source_template_type	EX	\N
98	35	geo_library_type	PE	\N
99	35	geo_tissue_origin	Ly	\N
100	35	geo_library_size_code	402	\N
101	36	geo_tissue_type	R	\N
102	36	geo_library_source_template_type	WG	\N
103	36	geo_library_type	PE	\N
104	36	geo_tissue_origin	Ly	\N
105	36	geo_library_size_code	500	\N
106	37	geo_tissue_type	P	\N
107	37	geo_library_source_template_type	WG	\N
108	37	geo_library_type	PE	\N
109	37	geo_tissue_origin	Pa	\N
110	37	geo_library_size_code	400	\N
\.


--
-- Data for Name: sample_hierarchy; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY sample_hierarchy (sample_id, parent_id) FROM stdin;
2	1
3	2
4	2
5	2
6	1
7	6
8	2
9	6
10	6
11	2
13	12
14	13
16	15
17	16
19	18
20	19
22	21
23	22
24	12
25	24
26	1
27	26
28	2
29	6
30	1
31	30
32	24
33	16
34	15
35	34
36	6
37	2
\.


--
-- Data for Name: sample_link; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY sample_link (sample_link_id, sample_id, label, url, db, id) FROM stdin;
\.


--
-- Data for Name: sample_relationship; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY sample_relationship (sample_relationship_id, parent_id, child_id, relationship) FROM stdin;
\.


--
-- Data for Name: sample_report; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY sample_report (study_id, child_sample_id, workflow_id, status, sequencer_run_id, lane_id, ius_id, row_id) FROM stdin;
\.


--
-- Data for Name: sample_search; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY sample_search (sample_search_id, sample_id, create_tstmp) FROM stdin;
\.


--
-- Data for Name: sample_search_attribute; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY sample_search_attribute (sample_search_attribute_id, sample_search_id, tag, value) FROM stdin;
\.


--
-- Data for Name: sequencer_run; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY sequencer_run (sequencer_run_id, name, description, status, platform_id, instrument_name, cycle_descriptor, cycle_count, cycle_sequence, file_path, paired_end, process, ref_lane, paired_file_path, use_ipar_intensities, color_matrix, color_matrix_code, slide_count, slide_1_lane_count, slide_1_file_path, slide_2_lane_count, slide_2_file_path, flow_sequence, flow_count, owner_id, run_center, base_caller, quality_scorer, sw_accession, create_tstmp, update_tstmp, skip) FROM stdin;
1	TEST_SEQUENCER_RUN_001	TEST_SEQUENCER_RUN_001	\N	20	\N	\N	\N	\N	/.mounts/labs/PDE/data/regressionTestStudy/TEST_HISEQ2000_RUN_0001	t	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	1	2013-04-11 15:16:16.9	2013-04-11 15:16:16.907	f
2	TEST_SEQUENCER_RUN_002	TEST_SEQUENCER_RUN_002	\N	20	\N	\N	\N	\N	/.mounts/labs/PDE/data/regressionTestStudy/TEST_HISEQ2000_RUN_0002	t	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	31	2013-04-11 15:37:44.248	2013-04-11 15:37:44.249	f
3	TEST_SEQUENCER_RUN_003	TEST_SEQUENCER_RUN_003	\N	20	\N	\N	\N	\N	/thisisjunk	t	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	76	2013-04-11 15:40:00.723	2013-04-11 16:21:33.1	t
\.


--
-- Data for Name: sequencer_run_attribute; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY sequencer_run_attribute (sequencer_run_attribute_id, sample_id, tag, value, units) FROM stdin;
1	3	skip	run skip	\N
\.


--
-- Data for Name: share_experiment; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY share_experiment (share_experiment_id, experiment_id, registration_id, active, sw_accession, create_tstmp, update_tstmp) FROM stdin;
\.


--
-- Data for Name: share_file; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY share_file (file_id, registration_id, active, sw_accession, create_tstmp, update_tstmp, share_file_id) FROM stdin;
\.


--
-- Data for Name: share_lane; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY share_lane (lane_id, registration_id, active, sw_accession, create_tstmp, update_tstmp, share_lane_id) FROM stdin;
\.


--
-- Data for Name: share_processing; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY share_processing (processing_id, registration_id, active, sw_accession, create_tstmp, update_tstmp, share_processing_id) FROM stdin;
\.


--
-- Data for Name: share_sample; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY share_sample (sample_id, registration_id, active, sw_accession, create_tstmp, update_tstmp, share_sample_id) FROM stdin;
\.


--
-- Data for Name: share_study; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY share_study (share_study_id, study_id, registration_id, active, sw_accession, create_tstmp, update_tstmp) FROM stdin;
\.


--
-- Data for Name: share_workflow_run; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY share_workflow_run (share_workflow_run_id, workflow_run_id, registration_id, active, sw_accession, create_tstmp, update_tstmp) FROM stdin;
\.


--
-- Data for Name: study; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY study (study_id, title, alias, description, accession, abstract, existing_type, new_type, center_name, center_project_name, project_id, status, owner_id, sw_accession, create_tstmp, update_tstmp) FROM stdin;
1	PDE_TEST	PDE_TEST	PDE_TEST	\N	\N	11	\N	OICR	PDE_TEST	0	\N	1	2	2013-04-11 15:16:17.112	2013-04-11 15:16:17.113
\.


--
-- Data for Name: study_attribute; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY study_attribute (study_attribute_id, study_id, tag, value, units) FROM stdin;
\.


--
-- Data for Name: study_link; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY study_link (study_link_id, study_id, label, url, db, id) FROM stdin;
\.


--
-- Data for Name: study_type; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY study_type (study_type_id, name, description) FROM stdin;
1	Whole Genome Sequencing	Sequencing of a single organism.
2	Metagenomics	Sequencing of a community.
3	Transcriptome Analysis	Sequencing and characterization of transcription elements.
4	Resequencing	Sequencing of a sample with respect to a reference.
5	Epigenetics	Cellular differentiation study.
6	Synthetic Genomics	Sequencing of modified, synthetic, or transplanted genomes.
7	Forensic or Paleo-genomics	Sequencing of recovered genomic material.
8	Gene Regulation Study	Study of gene expression regulation.
9	Cancer Genomics	Study of cancer genomics.
10	Population Genomics	Study of populations and evolution through genomics.
11	Other	Study type not listed.
\.


--
-- Data for Name: version; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY version (version_id, name, major, minor, bugfix, type) FROM stdin;
\.


--
-- Data for Name: workflow; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY workflow (workflow_id, name, description, input_algorithm, version, seqware_version, owner_id, base_ini_file, cmd, current_working_dir, host, username, workflow_template, create_tstmp, update_tstmp, sw_accession, permanent_bundle_location, workflow_class, workflow_type, workflow_engine) FROM stdin;
28	FileImport	Imports files into the database, links them to IUSs or Lanes and creates intermediate Processings. Initially used to import files from the LIMS and attach them to IUSes.	\N	0.1.0	0.10.0	\N	\N	\N	\N	\N	\N	\N	2012-01-04 13:51:00	\N	4	\N	\N	\N	\N
\.


--
-- Data for Name: workflow_attribute; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY workflow_attribute (workflow_attribute_id, workflow_id, tag, value, unit) FROM stdin;
\.


--
-- Data for Name: workflow_param; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY workflow_param (workflow_param_id, workflow_id, type, key, display, display_name, file_meta_type, default_value) FROM stdin;
\.


--
-- Data for Name: workflow_param_value; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY workflow_param_value (workflow_param_value_id, workflow_param_id, display_name, value) FROM stdin;
\.


--
-- Data for Name: workflow_run; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY workflow_run (workflow_run_id, workflow_id, owner_id, name, ini_file, cmd, workflow_template, dax, status, status_cmd, seqware_revision, host, current_working_dir, username, stderr, stdout, create_tstmp, update_tstmp, sw_accession, workflow_engine) FROM stdin;
\.


--
-- Data for Name: workflow_run_attribute; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY workflow_run_attribute (workflow_run_attribute_id, workflow_run_id, tag, value, unit) FROM stdin;
\.


--
-- Data for Name: workflow_run_param; Type: TABLE DATA; Schema: public; Owner: seqware
--

COPY workflow_run_param (workflow_run_param_id, workflow_run_id, type, key, parent_processing_accession, value) FROM stdin;
\.


--
-- Name: expense_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY expense_attribute
    ADD CONSTRAINT expense_attribute_pkey PRIMARY KEY (expense_attribute_id);


--
-- Name: expense_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY expense
    ADD CONSTRAINT expense_pkey PRIMARY KEY (expense_id);


--
-- Name: experiment_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY experiment_attribute
    ADD CONSTRAINT experiment_attribute_pkey PRIMARY KEY (experiment_attribute_id);


--
-- Name: experiment_library_design_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY experiment_library_design
    ADD CONSTRAINT experiment_library_design_pkey PRIMARY KEY (experiment_library_design_id);


--
-- Name: experiment_link_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY experiment_link
    ADD CONSTRAINT experiment_link_pkey PRIMARY KEY (experiment_link_id);


--
-- Name: experiment_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY experiment
    ADD CONSTRAINT experiment_pkey PRIMARY KEY (experiment_id);


--
-- Name: experiment_spot_design_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY experiment_spot_design
    ADD CONSTRAINT experiment_spot_design_pkey PRIMARY KEY (experiment_spot_design_id);


--
-- Name: experiment_spot_design_read_spec_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY experiment_spot_design_read_spec
    ADD CONSTRAINT experiment_spot_design_read_spec_pkey PRIMARY KEY (experiment_spot_design_read_spec_id);


--
-- Name: file_attribute_file_id_tag_value_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY file_attribute
    ADD CONSTRAINT file_attribute_file_id_tag_value_key UNIQUE (file_id, tag, value);


--
-- Name: file_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY file_attribute
    ADD CONSTRAINT file_attribute_pkey PRIMARY KEY (file_attribute_id);


--
-- Name: file_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY file
    ADD CONSTRAINT file_pkey PRIMARY KEY (file_id);


--
-- Name: file_report_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY file_report
    ADD CONSTRAINT file_report_pkey PRIMARY KEY (row_id);


--
-- Name: file_type_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY file_type
    ADD CONSTRAINT file_type_pkey PRIMARY KEY (file_type_id);


--
-- Name: invoice_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY invoice_attribute
    ADD CONSTRAINT invoice_attribute_pkey PRIMARY KEY (invoice_attribute_id);


--
-- Name: invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (invoice_id);


--
-- Name: ius_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY ius_attribute
    ADD CONSTRAINT ius_attribute_pkey PRIMARY KEY (ius_attribute_id);


--
-- Name: ius_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY ius
    ADD CONSTRAINT ius_pkey PRIMARY KEY (ius_id);


--
-- Name: lane_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY lane_attribute
    ADD CONSTRAINT lane_attribute_pkey PRIMARY KEY (lane_attribute_id);


--
-- Name: lane_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY lane
    ADD CONSTRAINT lane_pkey PRIMARY KEY (lane_id);


--
-- Name: lane_type_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY lane_type
    ADD CONSTRAINT lane_type_pkey PRIMARY KEY (lane_type_id);


--
-- Name: library_selection_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY library_selection
    ADD CONSTRAINT library_selection_pkey PRIMARY KEY (library_selection_id);


--
-- Name: library_source_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY library_source
    ADD CONSTRAINT library_source_pkey PRIMARY KEY (library_source_id);


--
-- Name: library_strategy_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY library_strategy
    ADD CONSTRAINT library_strategy_pkey PRIMARY KEY (library_strategy_id);


--
-- Name: organism_code_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY organism
    ADD CONSTRAINT organism_code_key UNIQUE (code);


--
-- Name: organism_ncbi_taxid_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY organism
    ADD CONSTRAINT organism_ncbi_taxid_key UNIQUE (ncbi_taxid);


--
-- Name: organism_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY organism
    ADD CONSTRAINT organism_pkey PRIMARY KEY (organism_id);


--
-- Name: pk_ius_link; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY ius_link
    ADD CONSTRAINT pk_ius_link PRIMARY KEY (ius_link_id);


--
-- Name: pk_ius_workflow_runs; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY ius_workflow_runs
    ADD CONSTRAINT pk_ius_workflow_runs PRIMARY KEY (ius_workflow_runs_id);


--
-- Name: pk_lane_link; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY lane_link
    ADD CONSTRAINT pk_lane_link PRIMARY KEY (lane_link_id);


--
-- Name: pk_lane_workflow_runs; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY lane_workflow_runs
    ADD CONSTRAINT pk_lane_workflow_runs PRIMARY KEY (lane_workflow_runs_id);


--
-- Name: pk_share_experiment; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY share_experiment
    ADD CONSTRAINT pk_share_experiment PRIMARY KEY (share_experiment_id);


--
-- Name: pk_share_file; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY share_file
    ADD CONSTRAINT pk_share_file PRIMARY KEY (share_file_id);


--
-- Name: pk_share_lane; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY share_lane
    ADD CONSTRAINT pk_share_lane PRIMARY KEY (share_lane_id);


--
-- Name: pk_share_processing; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY share_processing
    ADD CONSTRAINT pk_share_processing PRIMARY KEY (share_processing_id);


--
-- Name: pk_share_sample; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY share_sample
    ADD CONSTRAINT pk_share_sample PRIMARY KEY (share_sample_id);


--
-- Name: pk_workflow_param; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY workflow_param
    ADD CONSTRAINT pk_workflow_param PRIMARY KEY (workflow_param_id);


--
-- Name: pk_workflow_param_value; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY workflow_param_value
    ADD CONSTRAINT pk_workflow_param_value PRIMARY KEY (workflow_param_value_id);


--
-- Name: pk_workflow_run_param; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY workflow_run_param
    ADD CONSTRAINT pk_workflow_run_param PRIMARY KEY (workflow_run_param_id);


--
-- Name: platform_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY platform
    ADD CONSTRAINT platform_pkey PRIMARY KEY (platform_id);


--
-- Name: processing_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_attribute
    ADD CONSTRAINT processing_attribute_pkey PRIMARY KEY (processing_attribute_id);


--
-- Name: processing_experiments_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_experiments
    ADD CONSTRAINT processing_experiments_pkey PRIMARY KEY (processing_experiments_id);


--
-- Name: processing_experiments_unique_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_experiments
    ADD CONSTRAINT processing_experiments_unique_key UNIQUE (experiment_id, processing_id);


--
-- Name: processing_files_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_files
    ADD CONSTRAINT processing_files_pkey PRIMARY KEY (processing_files_id);


--
-- Name: processing_ius_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_ius
    ADD CONSTRAINT processing_ius_pkey PRIMARY KEY (processing_ius_id);


--
-- Name: processing_ius_unique_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_ius
    ADD CONSTRAINT processing_ius_unique_key UNIQUE (ius_id, processing_id);


--
-- Name: processing_lanes_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_lanes
    ADD CONSTRAINT processing_lanes_pkey PRIMARY KEY (processing_lanes_id);


--
-- Name: processing_lanes_unique_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_lanes
    ADD CONSTRAINT processing_lanes_unique_key UNIQUE (lane_id, processing_id);


--
-- Name: processing_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing
    ADD CONSTRAINT processing_pkey PRIMARY KEY (processing_id);


--
-- Name: processing_relationship_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_relationship
    ADD CONSTRAINT processing_relationship_pkey PRIMARY KEY (processing_relationship_id);


--
-- Name: processing_samples_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_samples
    ADD CONSTRAINT processing_samples_pkey PRIMARY KEY (processing_samples_id);


--
-- Name: processing_samples_unique_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_samples
    ADD CONSTRAINT processing_samples_unique_key UNIQUE (sample_id, processing_id);


--
-- Name: processing_sequencer_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_sequencer_runs
    ADD CONSTRAINT processing_sequencer_runs_pkey PRIMARY KEY (processing_sequencer_runs_id);


--
-- Name: processing_sequencer_runs_unique_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_sequencer_runs
    ADD CONSTRAINT processing_sequencer_runs_unique_key UNIQUE (sequencer_run_id, processing_id);


--
-- Name: processing_studies_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_studies
    ADD CONSTRAINT processing_studies_pkey PRIMARY KEY (processing_studies_id);


--
-- Name: processing_studies_unique_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY processing_studies
    ADD CONSTRAINT processing_studies_unique_key UNIQUE (study_id, processing_id);


--
-- Name: registration_email_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY registration
    ADD CONSTRAINT registration_email_key UNIQUE (email);


--
-- Name: registration_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY registration
    ADD CONSTRAINT registration_pkey PRIMARY KEY (registration_id);


--
-- Name: sample_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY sample_attribute
    ADD CONSTRAINT sample_attribute_pkey PRIMARY KEY (sample_attribute_id);


--
-- Name: sample_hierarchy_sample_id_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY sample_hierarchy
    ADD CONSTRAINT sample_hierarchy_sample_id_key UNIQUE (sample_id, parent_id);


--
-- Name: sample_link_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY sample_link
    ADD CONSTRAINT sample_link_pkey PRIMARY KEY (sample_link_id);


--
-- Name: sample_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY sample
    ADD CONSTRAINT sample_pkey PRIMARY KEY (sample_id);


--
-- Name: sample_relationship_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY sample_relationship
    ADD CONSTRAINT sample_relationship_pkey PRIMARY KEY (sample_relationship_id);


--
-- Name: sample_report_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY sample_report
    ADD CONSTRAINT sample_report_pkey PRIMARY KEY (row_id);


--
-- Name: sample_search_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY sample_search_attribute
    ADD CONSTRAINT sample_search_attribute_pkey PRIMARY KEY (sample_search_attribute_id);


--
-- Name: sample_search_attribute_sample_search_id_tag_value_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY sample_search_attribute
    ADD CONSTRAINT sample_search_attribute_sample_search_id_tag_value_key UNIQUE (sample_search_id, tag, value);


--
-- Name: sample_search_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY sample_search
    ADD CONSTRAINT sample_search_pkey PRIMARY KEY (sample_search_id);


--
-- Name: sequencer_run_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY sequencer_run_attribute
    ADD CONSTRAINT sequencer_run_attribute_pkey PRIMARY KEY (sequencer_run_attribute_id);


--
-- Name: sequencer_run_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY sequencer_run
    ADD CONSTRAINT sequencer_run_pkey PRIMARY KEY (sequencer_run_id);


--
-- Name: share_study_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY share_study
    ADD CONSTRAINT share_study_pkey PRIMARY KEY (share_study_id);


--
-- Name: share_workflow_run_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY share_workflow_run
    ADD CONSTRAINT share_workflow_run_pkey PRIMARY KEY (share_workflow_run_id);


--
-- Name: study_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY study_attribute
    ADD CONSTRAINT study_attribute_pkey PRIMARY KEY (study_attribute_id);


--
-- Name: study_link_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY study_link
    ADD CONSTRAINT study_link_pkey PRIMARY KEY (study_link_id);


--
-- Name: study_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY study
    ADD CONSTRAINT study_pkey PRIMARY KEY (study_id);


--
-- Name: study_type_name_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY study_type
    ADD CONSTRAINT study_type_name_key UNIQUE (name);


--
-- Name: study_type_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY study_type
    ADD CONSTRAINT study_type_pkey PRIMARY KEY (study_type_id);


--
-- Name: workflow_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY workflow_attribute
    ADD CONSTRAINT workflow_attribute_pkey PRIMARY KEY (workflow_attribute_id);


--
-- Name: workflow_attribute_workflow_id_tag_value_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY workflow_attribute
    ADD CONSTRAINT workflow_attribute_workflow_id_tag_value_key UNIQUE (workflow_id, tag, value);


--
-- Name: workflow_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY workflow
    ADD CONSTRAINT workflow_pkey PRIMARY KEY (workflow_id);


--
-- Name: workflow_run_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY workflow_run_attribute
    ADD CONSTRAINT workflow_run_attribute_pkey PRIMARY KEY (workflow_run_attribute_id);


--
-- Name: workflow_run_attribute_workflow_run_id_tag_value_key; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY workflow_run_attribute
    ADD CONSTRAINT workflow_run_attribute_workflow_run_id_tag_value_key UNIQUE (workflow_run_id, tag, value);


--
-- Name: workflow_run_pkey; Type: CONSTRAINT; Schema: public; Owner: seqware; Tablespace: 
--

ALTER TABLE ONLY workflow_run
    ADD CONSTRAINT workflow_run_pkey PRIMARY KEY (workflow_run_id);


--
-- Name: file_report_study_id_idx; Type: INDEX; Schema: public; Owner: seqware; Tablespace: 
--

CREATE INDEX file_report_study_id_idx ON file_report USING btree (study_id);


--
-- Name: index_processing_relationship_child_id; Type: INDEX; Schema: public; Owner: seqware; Tablespace: 
--

CREATE INDEX index_processing_relationship_child_id ON processing_relationship USING btree (child_id);


--
-- Name: index_processing_relationship_parent_id; Type: INDEX; Schema: public; Owner: seqware; Tablespace: 
--

CREATE INDEX index_processing_relationship_parent_id ON processing_relationship USING btree (parent_id);


--
-- Name: sample_report_study_id_child_sample_id_workflow_id_idx; Type: INDEX; Schema: public; Owner: seqware; Tablespace: 
--

CREATE INDEX sample_report_study_id_child_sample_id_workflow_id_idx ON sample_report USING btree (study_id, child_sample_id, workflow_id);


--
-- Name: expense_attribute_expense_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY expense_attribute
    ADD CONSTRAINT expense_attribute_expense_id_fkey FOREIGN KEY (expense_id) REFERENCES expense(expense_id);


--
-- Name: experiment__owner_fk; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment
    ADD CONSTRAINT experiment__owner_fk FOREIGN KEY (owner_id) REFERENCES registration(registration_id);


--
-- Name: experiment_attribute_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment_attribute
    ADD CONSTRAINT experiment_attribute_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES experiment(experiment_id);


--
-- Name: experiment_experiment_library_design_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment
    ADD CONSTRAINT experiment_experiment_library_design_id_fkey FOREIGN KEY (experiment_library_design_id) REFERENCES experiment_library_design(experiment_library_design_id);


--
-- Name: experiment_experiment_spot_design_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment
    ADD CONSTRAINT experiment_experiment_spot_design_id_fkey FOREIGN KEY (experiment_spot_design_id) REFERENCES experiment_spot_design(experiment_spot_design_id);


--
-- Name: experiment_library_design_selection_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment_library_design
    ADD CONSTRAINT experiment_library_design_selection_fkey FOREIGN KEY (selection) REFERENCES library_selection(library_selection_id);


--
-- Name: experiment_library_design_source_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment_library_design
    ADD CONSTRAINT experiment_library_design_source_fkey FOREIGN KEY (source) REFERENCES library_source(library_source_id);


--
-- Name: experiment_library_design_strategy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment_library_design
    ADD CONSTRAINT experiment_library_design_strategy_fkey FOREIGN KEY (strategy) REFERENCES library_strategy(library_strategy_id);


--
-- Name: experiment_link_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment_link
    ADD CONSTRAINT experiment_link_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES experiment(experiment_id);


--
-- Name: experiment_platform_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment
    ADD CONSTRAINT experiment_platform_id_fkey FOREIGN KEY (platform_id) REFERENCES platform(platform_id);


--
-- Name: experiment_spot_design_read_spec_experiment_spot_design_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment_spot_design_read_spec
    ADD CONSTRAINT experiment_spot_design_read_spec_experiment_spot_design_id_fkey FOREIGN KEY (experiment_spot_design_id) REFERENCES experiment_spot_design(experiment_spot_design_id);


--
-- Name: experiment_study_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY experiment
    ADD CONSTRAINT experiment_study_id_fkey FOREIGN KEY (study_id) REFERENCES study(study_id);


--
-- Name: fk2d251a1c685fba9d; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY workflow_attribute
    ADD CONSTRAINT fk2d251a1c685fba9d FOREIGN KEY (workflow_id) REFERENCES workflow(workflow_id);


--
-- Name: fk35f09d686071c5f8; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY workflow_run_attribute
    ADD CONSTRAINT fk35f09d686071c5f8 FOREIGN KEY (workflow_run_id) REFERENCES workflow_run(workflow_run_id);


--
-- Name: fk48cd19ddcc73e37d; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample_search
    ADD CONSTRAINT fk48cd19ddcc73e37d FOREIGN KEY (sample_id) REFERENCES sample(sample_id);


--
-- Name: fk7750ef99bb4f9efd; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY file_attribute
    ADD CONSTRAINT fk7750ef99bb4f9efd FOREIGN KEY (file_id) REFERENCES file(file_id);


--
-- Name: fk_file_file_type_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY file
    ADD CONSTRAINT fk_file_file_type_id FOREIGN KEY (file_type_id) REFERENCES file_type(file_type_id);


--
-- Name: fk_file_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY file
    ADD CONSTRAINT fk_file_owner_id FOREIGN KEY (owner_id) REFERENCES registration(registration_id);


--
-- Name: fk_ius_link_ius_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY ius_link
    ADD CONSTRAINT fk_ius_link_ius_id FOREIGN KEY (ius_id) REFERENCES ius(ius_id);


--
-- Name: fk_ius_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY ius
    ADD CONSTRAINT fk_ius_owner_id FOREIGN KEY (owner_id) REFERENCES registration(registration_id);


--
-- Name: fk_ius_workflow_runs_ius_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY ius_workflow_runs
    ADD CONSTRAINT fk_ius_workflow_runs_ius_id FOREIGN KEY (ius_id) REFERENCES ius(ius_id);


--
-- Name: fk_ius_workflow_runs_workflow_run_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY ius_workflow_runs
    ADD CONSTRAINT fk_ius_workflow_runs_workflow_run_id FOREIGN KEY (workflow_run_id) REFERENCES workflow_run(workflow_run_id);


--
-- Name: fk_lane_link_lane_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane_link
    ADD CONSTRAINT fk_lane_link_lane_id FOREIGN KEY (lane_id) REFERENCES lane(lane_id);


--
-- Name: fk_lane_workflow_runs_lane_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane_workflow_runs
    ADD CONSTRAINT fk_lane_workflow_runs_lane_id FOREIGN KEY (lane_id) REFERENCES lane(lane_id);


--
-- Name: fk_lane_workflow_runs_workflow_run_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane_workflow_runs
    ADD CONSTRAINT fk_lane_workflow_runs_workflow_run_id FOREIGN KEY (workflow_run_id) REFERENCES workflow_run(workflow_run_id);


--
-- Name: fk_processing_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing
    ADD CONSTRAINT fk_processing_owner_id FOREIGN KEY (owner_id) REFERENCES registration(registration_id);


--
-- Name: fk_sequencer_run_attribute_sequencer_run_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sequencer_run_attribute
    ADD CONSTRAINT fk_sequencer_run_attribute_sequencer_run_id FOREIGN KEY (sample_id) REFERENCES sequencer_run(sequencer_run_id);


--
-- Name: fk_share_experiment_experiment_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_experiment
    ADD CONSTRAINT fk_share_experiment_experiment_id FOREIGN KEY (experiment_id) REFERENCES experiment(experiment_id);


--
-- Name: fk_share_experiment_registration_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_experiment
    ADD CONSTRAINT fk_share_experiment_registration_id FOREIGN KEY (registration_id) REFERENCES registration(registration_id);


--
-- Name: fk_share_file_file_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_file
    ADD CONSTRAINT fk_share_file_file_id FOREIGN KEY (file_id) REFERENCES file(file_id);


--
-- Name: fk_share_file_registration_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_file
    ADD CONSTRAINT fk_share_file_registration_id FOREIGN KEY (registration_id) REFERENCES registration(registration_id);


--
-- Name: fk_share_lane_lane_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_lane
    ADD CONSTRAINT fk_share_lane_lane_id FOREIGN KEY (lane_id) REFERENCES lane(lane_id);


--
-- Name: fk_share_lane_registration_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_lane
    ADD CONSTRAINT fk_share_lane_registration_id FOREIGN KEY (registration_id) REFERENCES registration(registration_id);


--
-- Name: fk_share_processing_processing_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_processing
    ADD CONSTRAINT fk_share_processing_processing_id FOREIGN KEY (processing_id) REFERENCES processing(processing_id);


--
-- Name: fk_share_processing_registration_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_processing
    ADD CONSTRAINT fk_share_processing_registration_id FOREIGN KEY (registration_id) REFERENCES registration(registration_id);


--
-- Name: fk_share_sample_registration_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_sample
    ADD CONSTRAINT fk_share_sample_registration_id FOREIGN KEY (registration_id) REFERENCES registration(registration_id);


--
-- Name: fk_share_sample_sample_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_sample
    ADD CONSTRAINT fk_share_sample_sample_id FOREIGN KEY (sample_id) REFERENCES sample(sample_id);


--
-- Name: fk_share_study_registration_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_study
    ADD CONSTRAINT fk_share_study_registration_id FOREIGN KEY (registration_id) REFERENCES registration(registration_id);


--
-- Name: fk_share_study_study_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_study
    ADD CONSTRAINT fk_share_study_study_id FOREIGN KEY (study_id) REFERENCES study(study_id);


--
-- Name: fk_share_workflow_run_registration_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_workflow_run
    ADD CONSTRAINT fk_share_workflow_run_registration_id FOREIGN KEY (registration_id) REFERENCES registration(registration_id);


--
-- Name: fk_share_workflow_run_workflow_run_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY share_workflow_run
    ADD CONSTRAINT fk_share_workflow_run_workflow_run_id FOREIGN KEY (workflow_run_id) REFERENCES workflow_run(workflow_run_id);


--
-- Name: fk_workflow_param_value_workflow_param_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY workflow_param_value
    ADD CONSTRAINT fk_workflow_param_value_workflow_param_id FOREIGN KEY (workflow_param_id) REFERENCES workflow_param(workflow_param_id);


--
-- Name: fk_workflow_param_workflow_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY workflow_param
    ADD CONSTRAINT fk_workflow_param_workflow_id FOREIGN KEY (workflow_id) REFERENCES workflow(workflow_id);


--
-- Name: fk_workflow_registration_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY workflow
    ADD CONSTRAINT fk_workflow_registration_id FOREIGN KEY (owner_id) REFERENCES registration(registration_id);


--
-- Name: fk_workflow_run_param_workflow_run_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY workflow_run_param
    ADD CONSTRAINT fk_workflow_run_param_workflow_run_id FOREIGN KEY (workflow_run_id) REFERENCES workflow_run(workflow_run_id);


--
-- Name: fk_workflow_run_registration_id; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY workflow_run
    ADD CONSTRAINT fk_workflow_run_registration_id FOREIGN KEY (owner_id) REFERENCES registration(registration_id);


--
-- Name: fkf378ceba921d0a72; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample_search_attribute
    ADD CONSTRAINT fkf378ceba921d0a72 FOREIGN KEY (sample_search_id) REFERENCES sample_search(sample_search_id);


--
-- Name: invoice_attribute_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY invoice_attribute
    ADD CONSTRAINT invoice_attribute_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES invoice(invoice_id);


--
-- Name: invoice_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY expense
    ADD CONSTRAINT invoice_id_fk FOREIGN KEY (invoice_id) REFERENCES invoice(invoice_id);


--
-- Name: invoice_owner_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT invoice_owner_id_fk FOREIGN KEY (owner_id) REFERENCES registration(registration_id);


--
-- Name: ius__lane_fk; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY ius
    ADD CONSTRAINT ius__lane_fk FOREIGN KEY (lane_id) REFERENCES lane(lane_id);


--
-- Name: ius__sample_fk; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY ius
    ADD CONSTRAINT ius__sample_fk FOREIGN KEY (sample_id) REFERENCES sample(sample_id);


--
-- Name: ius_attribute_ius_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY ius_attribute
    ADD CONSTRAINT ius_attribute_ius_id_fkey FOREIGN KEY (ius_id) REFERENCES ius(ius_id);


--
-- Name: lane_attribute_lane_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane_attribute
    ADD CONSTRAINT lane_attribute_lane_id_fkey FOREIGN KEY (lane_id) REFERENCES lane(lane_id);


--
-- Name: lane_library_selection_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane
    ADD CONSTRAINT lane_library_selection_fkey FOREIGN KEY (library_selection) REFERENCES library_selection(library_selection_id);


--
-- Name: lane_library_source_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane
    ADD CONSTRAINT lane_library_source_fkey FOREIGN KEY (library_source) REFERENCES library_source(library_source_id);


--
-- Name: lane_library_strategy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane
    ADD CONSTRAINT lane_library_strategy_fkey FOREIGN KEY (library_strategy) REFERENCES library_strategy(library_strategy_id);


--
-- Name: lane_organism_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane
    ADD CONSTRAINT lane_organism_id_fkey FOREIGN KEY (organism_id) REFERENCES organism(organism_id);


--
-- Name: lane_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane
    ADD CONSTRAINT lane_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES registration(registration_id);


--
-- Name: lane_sample_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane
    ADD CONSTRAINT lane_sample_id_fkey FOREIGN KEY (sample_id) REFERENCES sample(sample_id);


--
-- Name: lane_sequencer_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane
    ADD CONSTRAINT lane_sequencer_run_id_fkey FOREIGN KEY (sequencer_run_id) REFERENCES sequencer_run(sequencer_run_id);


--
-- Name: lane_study_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane
    ADD CONSTRAINT lane_study_type_fkey FOREIGN KEY (study_type) REFERENCES study_type(study_type_id);


--
-- Name: lane_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY lane
    ADD CONSTRAINT lane_type_fkey FOREIGN KEY (type) REFERENCES lane_type(lane_type_id);


--
-- Name: processing_ancestor_workflow_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing
    ADD CONSTRAINT processing_ancestor_workflow_run_id_fkey FOREIGN KEY (ancestor_workflow_run_id) REFERENCES workflow_run(workflow_run_id);


--
-- Name: processing_attribute_processing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_attribute
    ADD CONSTRAINT processing_attribute_processing_id_fkey FOREIGN KEY (processing_id) REFERENCES processing(processing_id);


--
-- Name: processing_experiments_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_experiments
    ADD CONSTRAINT processing_experiments_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES experiment(experiment_id);


--
-- Name: processing_experiments_processing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_experiments
    ADD CONSTRAINT processing_experiments_processing_id_fkey FOREIGN KEY (processing_id) REFERENCES processing(processing_id);


--
-- Name: processing_files_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_files
    ADD CONSTRAINT processing_files_file_id_fkey FOREIGN KEY (file_id) REFERENCES file(file_id);


--
-- Name: processing_files_processing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_files
    ADD CONSTRAINT processing_files_processing_id_fkey FOREIGN KEY (processing_id) REFERENCES processing(processing_id);


--
-- Name: processing_ius_ius_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_ius
    ADD CONSTRAINT processing_ius_ius_id_fkey FOREIGN KEY (ius_id) REFERENCES ius(ius_id);


--
-- Name: processing_ius_processing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_ius
    ADD CONSTRAINT processing_ius_processing_id_fkey FOREIGN KEY (processing_id) REFERENCES processing(processing_id);


--
-- Name: processing_lanes_lane_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_lanes
    ADD CONSTRAINT processing_lanes_lane_id_fkey FOREIGN KEY (lane_id) REFERENCES lane(lane_id);


--
-- Name: processing_lanes_processing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_lanes
    ADD CONSTRAINT processing_lanes_processing_id_fkey FOREIGN KEY (processing_id) REFERENCES processing(processing_id);


--
-- Name: processing_relationship_child_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_relationship
    ADD CONSTRAINT processing_relationship_child_id_fkey FOREIGN KEY (child_id) REFERENCES processing(processing_id) ON DELETE CASCADE;


--
-- Name: processing_relationship_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_relationship
    ADD CONSTRAINT processing_relationship_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES processing(processing_id);


--
-- Name: processing_samples_processing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_samples
    ADD CONSTRAINT processing_samples_processing_id_fkey FOREIGN KEY (processing_id) REFERENCES processing(processing_id);


--
-- Name: processing_samples_sample_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_samples
    ADD CONSTRAINT processing_samples_sample_id_fkey FOREIGN KEY (sample_id) REFERENCES sample(sample_id);


--
-- Name: processing_sequencer_runs_processing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_sequencer_runs
    ADD CONSTRAINT processing_sequencer_runs_processing_id_fkey FOREIGN KEY (processing_id) REFERENCES processing(processing_id);


--
-- Name: processing_sequencer_runs_sequencer_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_sequencer_runs
    ADD CONSTRAINT processing_sequencer_runs_sequencer_run_id_fkey FOREIGN KEY (sequencer_run_id) REFERENCES sequencer_run(sequencer_run_id);


--
-- Name: processing_studies_processing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_studies
    ADD CONSTRAINT processing_studies_processing_id_fkey FOREIGN KEY (processing_id) REFERENCES processing(processing_id);


--
-- Name: processing_studies_study_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing_studies
    ADD CONSTRAINT processing_studies_study_id_fkey FOREIGN KEY (study_id) REFERENCES study(study_id);


--
-- Name: processing_workflow_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY processing
    ADD CONSTRAINT processing_workflow_run_id_fkey FOREIGN KEY (workflow_run_id) REFERENCES workflow_run(workflow_run_id);


--
-- Name: sample__organism_fk; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample
    ADD CONSTRAINT sample__organism_fk FOREIGN KEY (organism_id) REFERENCES organism(organism_id);


--
-- Name: sample__owner_fk; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample
    ADD CONSTRAINT sample__owner_fk FOREIGN KEY (owner_id) REFERENCES registration(registration_id);


--
-- Name: sample_attribute_sample_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample_attribute
    ADD CONSTRAINT sample_attribute_sample_id_fkey FOREIGN KEY (sample_id) REFERENCES sample(sample_id);


--
-- Name: sample_experiment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample
    ADD CONSTRAINT sample_experiment_id_fkey FOREIGN KEY (experiment_id) REFERENCES experiment(experiment_id);


--
-- Name: sample_hierarchy_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample_hierarchy
    ADD CONSTRAINT sample_hierarchy_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES sample(sample_id);


--
-- Name: sample_hierarchy_sample_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample_hierarchy
    ADD CONSTRAINT sample_hierarchy_sample_id_fkey FOREIGN KEY (sample_id) REFERENCES sample(sample_id);


--
-- Name: sample_link_sample_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample_link
    ADD CONSTRAINT sample_link_sample_id_fkey FOREIGN KEY (sample_id) REFERENCES sample(sample_id);


--
-- Name: sample_relationship_child_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample_relationship
    ADD CONSTRAINT sample_relationship_child_id_fkey FOREIGN KEY (child_id) REFERENCES sample(sample_id) ON DELETE CASCADE;


--
-- Name: sample_relationship_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sample_relationship
    ADD CONSTRAINT sample_relationship_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES sample(sample_id);


--
-- Name: sequencer_run_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sequencer_run
    ADD CONSTRAINT sequencer_run_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES registration(registration_id);


--
-- Name: sequencer_run_platform_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY sequencer_run
    ADD CONSTRAINT sequencer_run_platform_id_fkey FOREIGN KEY (platform_id) REFERENCES platform(platform_id);


--
-- Name: study_attribute_study_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY study_attribute
    ADD CONSTRAINT study_attribute_study_id_fkey FOREIGN KEY (study_id) REFERENCES study(study_id);


--
-- Name: study_existing_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY study
    ADD CONSTRAINT study_existing_type_fkey FOREIGN KEY (existing_type) REFERENCES study_type(study_type_id);


--
-- Name: study_link_study_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY study_link
    ADD CONSTRAINT study_link_study_id_fkey FOREIGN KEY (study_id) REFERENCES study(study_id);


--
-- Name: study_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY study
    ADD CONSTRAINT study_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES registration(registration_id);


--
-- Name: workflow_run_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seqware
--

ALTER TABLE ONLY workflow_run
    ADD CONSTRAINT workflow_run_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES workflow(workflow_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

